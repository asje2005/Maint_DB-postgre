# Implementing Datum in the MaintDB app

Your app's look is entirely token-driven: `utils/theme.py` builds a `:root` block
from a Python dict, and `static/styles.css` only ever references `var(--token)`.

**This folder contains three ready-to-commit files** — drop them into your repo,
restart, and the app is fully Datum. (The `MaintDB/` source is mounted read-only,
so these live here for you to copy across.)

| File in `handoff/` | Copy to |
|---|---|
| `theme.py`   | `MaintDB/utils/theme.py` |
| `app.py`     | `MaintDB/app.py` |
| `styles.css` | `MaintDB/static/styles.css` |

```bash
cp handoff/theme.py   MaintDB/utils/theme.py
cp handoff/app.py     MaintDB/app.py
cp handoff/styles.css MaintDB/static/styles.css
```

## What each file changes

**`theme.py`** — the Datum palette, fonts, radii, shadows. Same dict keys as
before, so all existing CSS keeps resolving. Adds the Space Grotesk + Space Mono
Google Fonts `@import`, a `--font-mono` token, and flattens the header/metric
"gradient" to a subtle teal (no more teal→blue gradient text).

**`app.py`** — identical logic to your original, with two brand edits applied:
1. The sidebar `🔧 Operation Database` title is replaced with the **Datum wordmark
   lockup** (inline SVG mark + "Datum / MAINTENANCE REFERENCE").
2. **Every emoji removed** from headers, buttons, captions, and status messages
   (🔧📋🔋⚙️⚡🛠➕✏️🗑️🎉🔒🔍🛈 …). Line characters and arrows (─ → ←) are kept —
   they're typographic, not emoji.

**`styles.css`** — your original plus the `.datum-brand / .datum-name /
.datum-sub` rules for the wordmark, and a rule routing inline `<code>` /
identifiers to the Space Mono face.

## One manual step — `.streamlit/config.toml`

Streamlit reads this file before any Python runs, so it can't be themed from
`theme.py`. Update the five colors to match Datum:

```toml
[theme]
primaryColor            = "#0d7a70"
backgroundColor         = "#f5f7f6"
secondaryBackgroundColor = "#ffffff"
textColor               = "#14211f"
font                    = "sans serif"
```

## Optional follow-ups (not required)

- **Richer icons:** buttons (`st.button`) take plain text only, so emoji there were
  simply removed. To put line icons back into your *HTML* `st.markdown` blocks,
  inject the Bootstrap-Icons stylesheet once and use `<i class="bi bi-…"></i>`.
  Map: 🔧 `bi-wrench-adjustable` · 📋 `bi-clipboard-check` · 🔋 `bi-battery-half` ·
  ⚙️ `bi-gear` · ⚡ `bi-lightning-charge` · 🛠 `bi-tools`.
- **`st.balloons()`** celebratory calls remain (behavior, not emoji). Remove if you
  want a more buttoned-up feel.
- **Burnt-amber warning state:** the `--warn` family (`#d98324`) is available for
  PM-due / overrun cases — wire it into the battery-cadence and job-overrun cards
  via `theme.badge(text, "warn")` / `value_gradient` if you add a warn gradient.

## Token reference

Full palette in `tokens/colors.css`; specimen cards in `guidelines/`; live
components in `components/` and the app recreation in `ui_kits/datum/`.
