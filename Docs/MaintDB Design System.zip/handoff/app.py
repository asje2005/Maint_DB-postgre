import streamlit as st
import streamlit.components.v1 as components
from streamlit_option_menu import option_menu
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
from sqlalchemy import text

APP_VERSION = "1.2.0"

# Call set_page_config as the absolute FIRST Streamlit command
st.set_page_config(
    page_title="Manufacturing Operation Database",
    layout="wide",
    initial_sidebar_state="expanded"
)

from utils.db import get_engine
from utils import theme
from utils.theme import metric_card as _metric_card

# -----------------------------------------------------------------------------
# DESIGN SYSTEM CSS
# -----------------------------------------------------------------------------
st.markdown(theme.get_css(), unsafe_allow_html=True)

# This app is designed light-only. Streamlit's built-in Dark theme makes the
# canvas-based widgets (dataframes / data_editor) render dark and unreadable,
# and config base="light" can't override a visitor's saved Dark selection. So
# if a saved Dark theme is found, clear it (reverting to the configured light
# theme) and reload. The condition is self-terminating — after the reset the
# theme is no longer Dark — and a session flag caps it at one reload, so it can
# never loop.
components.html(
    """
    <script>
    (function () {
      try {
        var w = window.top || window.parent;
        if (!w) return;
        var darkKey = null;
        for (var i = 0; i < w.localStorage.length; i++) {
          var k = w.localStorage.key(i);
          if (k && k.indexOf('stActiveTheme') === 0) {
            var v = w.localStorage.getItem(k);
            try { if (v && JSON.parse(v).name === 'Dark') darkKey = k; } catch (e) {}
          }
        }
        if (darkKey && !w.sessionStorage.getItem('mdbThemeReset')) {
          w.sessionStorage.setItem('mdbThemeReset', '1');
          w.localStorage.removeItem(darkKey);
          w.location.reload();
        }
      } catch (e) {}
    })();
    </script>
    """,
    height=0,
)

# -----------------------------------------------------------------------------
# APP ROUTING & NAVIGATION
# -----------------------------------------------------------------------------
if "page" not in st.session_state:
    st.session_state.page = "Home"

_NAV_LABELS  = ["Dashboard", "Add Asset", "Asset Registry", "Service Reports", "ERP Dashboard", "ETL & Analysis", "Records Manager"]
_NAV_ICONS   = ["speedometer2", "plus-circle", "clipboard-data", "wrench-adjustable", "bar-chart-line", "funnel", "table"]
_NAV_TO_PAGE = {
    "Dashboard":       "Home",
    "Add Asset":       "Add Asset",
    "Asset Registry":  "View Assets",
    "Service Reports": "Service Reports",
    "ERP Dashboard":   "ERP Dashboard",
    "ETL & Analysis":  "ETL Practice",
    "Records Manager": "Records Manager",
}
_PAGE_TO_NAV = {
    "Home":            "Dashboard",
    "Add Asset":       "Add Asset",
    "View Assets":     "Asset Registry",
    "Service Reports": "Service Reports",
    "ERP Dashboard":   "ERP Dashboard",
    "ETL Practice":    "ETL & Analysis",
    "Edit Asset":      "Asset Registry",
    "Records Manager": "Records Manager",
}


def _set_page(page_name):
    """Switch pages from a button and keep the sidebar menu in sync.

    The sidebar option_menu owns its own selection state (it has a fixed key),
    so a plain ``session_state.page = ...`` would leave the menu pointing at the
    old item and bounce the user right back. Stashing the target index in
    ``_nav_jump`` makes the menu jump to it via ``manual_select`` on the rerun.
    """
    st.session_state.page = page_name
    label = _PAGE_TO_NAV.get(page_name)
    if label is not None:
        st.session_state["_nav_jump"] = _NAV_LABELS.index(label)


with st.sidebar:
    st.markdown('''<div class="datum-brand">
      <svg width="32" height="32" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="48" height="48" rx="10" fill="#102A2A"/>
        <rect x="11" y="14" width="26" height="14.5" rx="2.5" stroke="#15A094" stroke-width="2.6"/>
        <circle cx="24" cy="21.25" r="2.7" fill="#15A094"/>
        <path d="M24 28.5v3.8" stroke="#15A094" stroke-width="2.6" stroke-linecap="round"/>
        <path d="M20 32.2h8L24 38.5z" fill="#15A094"/>
        <rect x="15.5" y="39.6" width="17" height="2.5" rx="1.25" fill="#15A094"/>
      </svg>
      <div class="datum-wm"><div class="datum-name">Datum</div><div class="datum-sub">MAINTENANCE REFERENCE</div></div>
    </div>''', unsafe_allow_html=True)

    current_label = _PAGE_TO_NAV.get(st.session_state.page, "Dashboard")
    default_idx   = _NAV_LABELS.index(current_label)

    # A fixed key keeps the menu's selection across reruns; without it the menu
    # re-mounts whenever default_index changes and silently swallows every other
    # click. Button-driven navigation moves the menu via manual_select (_nav_jump).
    manual_sel = st.session_state.pop("_nav_jump", None)

    selected = option_menu(
        menu_title=None,
        options=_NAV_LABELS,
        icons=_NAV_ICONS,
        default_index=default_idx,
        manual_select=manual_sel,
        key="main_nav",
        styles={
            "container":         {"padding": "4px 0", "background-color": theme.PALETTE["surface"]},
            "icon":              {"color": theme.PALETTE["text-muted"], "font-size": "15px"},
            "nav-link": {
                "font-size":     "0.9rem",
                "font-weight":   "500",
                "color":         theme.PALETTE["text-strong"],
                "padding":       "10px 14px",
                "border-radius": "8px",
                "margin":        "2px 0",
                "--hover-color": theme.PALETTE["primary-light"],
            },
            "nav-link-selected": {
                "background-color": theme.PALETTE["primary-light"],
                "color":         theme.PALETTE["primary-dark"],
                "font-weight":   "600",
                "border-left":   f'3px solid {theme.PALETTE["primary"]}',
                "padding-left":  "11px",
            },
        },
    )

    target_page = _NAV_TO_PAGE.get(selected, "Home")
    # Only let the nav override page if the user actually clicked a different item.
    # Guard prevents "Edit Asset" (which maps to "Asset Registry" in the nav) from
    # being immediately replaced with "View Assets" on every render.
    if not (st.session_state.page == "Edit Asset" and selected == current_label):
        st.session_state.page = target_page

    st.divider()
    st.caption("Quick Links")
    st.link_button("MSC Vending Portal", "https://vending.mscdirect.com/", use_container_width=True)
    st.link_button("DMG Mori Portal", "https://us.mydmgmori.com/en-US/#/portal/inquiry/list", use_container_width=True)

    st.divider()
    if st.button("Refresh Data", use_container_width=True):
        st.cache_data.clear()
        st.rerun()
    st.caption(f"v{APP_VERSION}")

# -----------------------------------------------------------------------------
# SHARED HELPERS
# -----------------------------------------------------------------------------

# _metric_card is imported from utils.theme (aliased above) so the markup lives
# next to its CSS classes; all metric cards share one definition.


def _require_db():
    """Return the SQLAlchemy engine if the database is reachable; show an error and return None otherwise."""
    try:
        eng = get_engine()
        with eng.connect() as _c:
            _c.execute(text("SELECT 1"))
        return eng
    except Exception as e:
        st.error(f"Cannot connect to the database: {e}")
        return None

# -----------------------------------------------------------------------------
# PAGE 1: HOME / DASHBOARD
# -----------------------------------------------------------------------------
def render_home_page():
    st.markdown('<div class="gradient-header">System Dashboard</div>', unsafe_allow_html=True)

    engine = _require_db()
    if engine is None:
        return

    with engine.connect() as _conn:
        asset_count     = _conn.execute(text("SELECT COUNT(*) FROM assets")).scalar()
        draft_count     = _conn.execute(text("SELECT COUNT(*) FROM service_reports WHERE record_state = 'Draft'")).scalar()
        finalized_count = _conn.execute(text("SELECT COUNT(*) FROM service_reports WHERE record_state = 'Final'")).scalar()
        draft_rows      = _conn.execute(text(
            "SELECT asset_code, service_type, problem_description, created_at "
            "FROM service_reports WHERE record_state = 'Draft' ORDER BY created_at DESC"
        )).mappings().fetchall()
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown(_metric_card("Registered Assets", asset_count), unsafe_allow_html=True)
    with col2:
        st.markdown(_metric_card("Open Drafts (WIP)", draft_count), unsafe_allow_html=True)
    with col3:
        st.markdown(_metric_card("Finalized Reports", finalized_count), unsafe_allow_html=True)
        
    st.markdown("---")
    
    left_col, right_col = st.columns([2, 1])
    
    with left_col:
        st.subheader("Active Work-in-Progress Drafts")
        if not draft_rows:
            st.info("No service drafts are currently open.")
        else:
            for dr in draft_rows:
                asset_code    = dr["asset_code"] or "Unknown"
                creation_time = dr["created_at"].strftime("%Y-%m-%d %H:%M") if dr["created_at"] else "Unknown"
                service_type  = dr["service_type"] or "Unknown"
                problem       = dr["problem_description"] or "No description provided."

                st.markdown(f"""
                <div class="asset-item" style="border-left-color: var(--info-accent); background-color: rgba(var(--info-accent-rgb), 0.04);">
                    <div style="float:right; color:var(--info); font-weight:600; font-size:0.875rem; letter-spacing: 0.05em; text-transform: uppercase;">Draft</div>
                    <div class="asset-title">Draft — {asset_code}</div>
                    <div>
                        {theme.badge(service_type, "info")}
                        <span style="color:var(--text-muted); font-size:0.85rem;">Last saved: {creation_time}</span>
                    </div>
                    <div style="margin-top:10px; color:var(--text-strong); font-size:0.9rem;">
                        <strong>Problem Description:</strong> {problem[:150] + '...' if len(problem) > 150 else problem}
                    </div>
                </div>
                """, unsafe_allow_html=True)

    with right_col:
        st.subheader("Quick Actions")
        if st.button("Create New Asset", use_container_width=True):
            _set_page("Add Asset")
            st.rerun()
        if st.button("Create Service Draft", use_container_width=True):
            st.session_state.service_page = "Create Service Draft"
            _set_page("Service Reports")
            st.rerun()
        if st.button("Edit Existing Draft", use_container_width=True):
            st.session_state.service_page = "Edit Existing Draft"
            _set_page("Service Reports")
            st.rerun()

# -----------------------------------------------------------------------------
# PAGE 2: ADD NEW ASSET
# -----------------------------------------------------------------------------
def render_add_asset_page():
    st.markdown('<div class="gradient-header">Register New Asset</div>', unsafe_allow_html=True)

    engine = _require_db()
    if engine is None:
        return

    department = st.selectbox(
        "Department Code",
        ["L", "M", "S", "Q", "E"],
        help="L = Lathe, M = Mill, S = Swiss, Q = Quality Control, E = Utility/Support"
    )
    
    # Auto-generate suggestion dynamically
    with engine.connect() as _conn:
        _rows = _conn.execute(
            text("SELECT asset_code FROM assets WHERE department_code = :dept"),
            {"dept": department}
        ).fetchall()
    _numbers = [int(r[0][len(department):]) for r in _rows if r[0][len(department):].isdigit()]
    next_num = max(_numbers) + 1 if _numbers else 1
    suggested_code = f"{department}{str(next_num).zfill(3)}"
    
    st.info(f"The next available code in department **{department}** is **{suggested_code}**.")
    
    # We construct a form
    with st.form("new_asset_form", clear_on_submit=False):
        
        col1, col2 = st.columns(2)
        with col1:
            asset_code = st.text_input(
                "Asset Code",
                value=suggested_code,
                help="Consists of 1 department letter and 3 sequence digits (e.g. L001)"
            )
            equipment_category = st.selectbox(
                "Equipment Category",
                ["Lathe", "Mill", "Swiss", "QC", "Support", "Other"]
            )
        with col2:
            manufacturer = st.text_input("Manufacturer", placeholder="e.g. Haas, Doosan")
            model = st.text_input("Model Name/Number", placeholder="e.g. VF-2, Lynx 2100")
            
        st.markdown("---")
        st.subheader("Technical & Distributor Information")
        
        col3, col4 = st.columns(2)
        with col3:
            serial_number = st.text_input("Serial Number")
            control_type = st.text_input("Control Type", placeholder="e.g. Fanuc, Haas, Mitsubishi")
            build_year = st.number_input("Build Year", min_value=1900, max_value=2100,
                                         value=None, step=1, format="%d", placeholder="e.g. 2024")
        with col4:
            distributor = st.text_input("Distributor Name")
            distributor_email = st.text_input("Distributor Email(s)")
            distributor_phone = st.text_input("Distributor Phone")
            
        vendor_contacts = st.text_area("Vendor / Specialist Contacts", placeholder="Notes on support engineers, repair techs, etc.")
        
        st.markdown("---")
        
        # Sub-equipments in expander for clean visual separation
        with st.expander("Additional / Sub-Equipment details (Optional)"):
            col_eq1, col_eq2, col_eq3 = st.columns(3)
            with col_eq1:
                st.markdown("#### Sub-Equipment 1")
                eq1_name = st.text_input("Name", key="eq1_name")
                eq1_make = st.text_input("Make", key="eq1_make")
                eq1_model = st.text_input("Model", key="eq1_model")
                eq1_serial = st.text_input("Serial Number", key="eq1_serial")
            with col_eq2:
                st.markdown("#### Sub-Equipment 2")
                eq2_name = st.text_input("Name", key="eq2_name")
                eq2_make = st.text_input("Make", key="eq2_make")
                eq2_model = st.text_input("Model", key="eq2_model")
                eq2_serial = st.text_input("Serial Number", key="eq2_serial")
            with col_eq3:
                st.markdown("#### Sub-Equipment 3")
                eq3_name = st.text_input("Name", key="eq3_name")
                eq3_make = st.text_input("Make", key="eq3_make")
                eq3_model = st.text_input("Model", key="eq3_model")
                eq3_serial = st.text_input("Serial Number", key="eq3_serial")
                
        # Batteries in expander
        with st.expander("Backup Battery Configuration (Optional)"):
            col_bat1, col_bat2 = st.columns(2)
            with col_bat1:
                st.markdown("#### Battery 1")
                battery_1_desc = st.text_input("Description", placeholder="e.g. Fanuc CNC Memory backup")
                battery_1_part = st.text_input("Part Number")
                battery_1_interval = st.number_input("Replacement Interval (Days)", min_value=0, value=365, step=30)
            with col_bat2:
                st.markdown("#### Battery 2")
                battery_2_desc = st.text_input("Description", placeholder="e.g. Main drive encoder backup")
                battery_2_part = st.text_input("Part Number", key="bat2_part")
                battery_2_interval = st.number_input("Replacement Interval (Days)", min_value=0, value=0, step=30, key="bat2_interval")
                
        submit = st.form_submit_button("Register Asset", use_container_width=True)
        
    if submit:
        # Form Validation
        asset_code = asset_code.strip().upper()
        if not asset_code:
            st.error("Asset Code is required")
            st.stop()
            
        if len(asset_code) != 4 or not asset_code[0].isalpha() or not asset_code[1:].isdigit():
            st.error("Asset Code must consist of a letter followed by three numbers (e.g. L001, M002)")
            st.stop()
            
        model_clean = model.strip()
        short_name = f"{asset_code}-{model_clean}" if model_clean else asset_code

        # Check uniqueness
        with engine.connect() as _conn:
            _exists = _conn.execute(
                text("SELECT 1 FROM assets WHERE asset_code = :code"),
                {"code": asset_code}
            ).fetchone()
        if _exists:
            st.error(f"An asset with code {asset_code} already exists in the system!")
            st.stop()
            
        try:
            with engine.connect() as _conn:
                _conn.execute(text("""
                    INSERT INTO assets (
                        asset_id, asset_code, department_code, sequence_number,
                        display_name, short_name, equipment_category,
                        manufacturer, model, serial_number, control_type, build_year,
                        distributor, distributor_email, distributor_phone, vendor_contacts,
                        template_version, registry_creation_date
                    ) VALUES (
                        :asset_id, :asset_code, :dept_code, :seq_num,
                        :display_name, :short_name, :category,
                        :manufacturer, :model, :serial_number, :control_type, :build_year,
                        :distributor, :distributor_email, :distributor_phone, :vendor_contacts,
                        '1.0', NOW()
                    )
                """), {
                    "asset_id":        f"A-{asset_code}",
                    "asset_code":      asset_code,
                    "dept_code":       asset_code[0],
                    "seq_num":         asset_code[1:],
                    "display_name":    short_name,
                    "short_name":      short_name,
                    "category":        equipment_category,
                    "manufacturer":    manufacturer.strip(),
                    "model":           model.strip(),
                    "serial_number":   serial_number.strip(),
                    "control_type":    control_type.strip(),
                    "build_year":      int(build_year) if build_year is not None else None,
                    "distributor":     distributor.strip(),
                    "distributor_email": distributor_email.strip(),
                    "distributor_phone": distributor_phone.strip(),
                    "vendor_contacts": vendor_contacts.strip(),
                })

                for n, (desc, part, interval) in enumerate([
                    (battery_1_desc, battery_1_part, battery_1_interval),
                    (battery_2_desc, battery_2_part, battery_2_interval),
                ], start=1):
                    if desc or part:
                        _conn.execute(text("""
                            INSERT INTO asset_batteries
                                (asset_id, battery_number, description, part_number, replacement_interval_days)
                            VALUES (:aid, :n, :desc, :part, :interval)
                        """), {"aid": f"A-{asset_code}", "n": n, "desc": desc,
                               "part": part, "interval": interval or 0})

                for n, (name, make, mdl, serial) in enumerate([
                    (eq1_name, eq1_make, eq1_model, eq1_serial),
                    (eq2_name, eq2_make, eq2_model, eq2_serial),
                    (eq3_name, eq3_make, eq3_model, eq3_serial),
                ], start=1):
                    if name:
                        _conn.execute(text("""
                            INSERT INTO asset_peripheral_equipment
                                (asset_id, equip_number, name, make, model, serial_number)
                            VALUES (:aid, :n, :name, :make, :model, :serial)
                        """), {"aid": f"A-{asset_code}", "n": n, "name": name,
                               "make": make, "model": mdl, "serial": serial})

                _conn.commit()

            st.success(f"Asset **{short_name}** successfully created and saved to registry!")
            st.balloons()
            st.rerun()

        except Exception as e:
            st.error(f"Error creating asset: {e}")

# -----------------------------------------------------------------------------
# PAGE 3: VIEW ASSETS REGISTRY
# -----------------------------------------------------------------------------
def render_view_assets_page():
    st.markdown('<div class="gradient-header">Asset Registry</div>', unsafe_allow_html=True)

    engine = _require_db()
    if engine is None:
        return

    assets_df = pd.read_sql_query("""
        SELECT a.asset_id, a.asset_code, a.manufacturer, a.model, a.serial_number,
               a.equipment_category, a.build_year, a.control_type, a.distributor,
               a.distributor_email, a.distributor_phone, a.vendor_contacts,
               b.description          AS battery_1_desc,
               b.replacement_interval_days AS battery_1_interval,
               (SELECT COUNT(*) FROM asset_peripheral_equipment p WHERE p.asset_id = a.asset_id) AS eq_count,
               (SELECT COUNT(*) FROM service_reports sr WHERE sr.asset_id = a.asset_id AND sr.record_state = 'Final') AS report_count
        FROM assets a
        LEFT JOIN asset_batteries b ON a.asset_id = b.asset_id AND b.battery_number = 1
        ORDER BY a.asset_id
    """, engine)
    equip_df = pd.read_sql_query(
        "SELECT asset_id, equip_number, name, make, model, serial_number FROM asset_peripheral_equipment ORDER BY asset_id, equip_number",
        engine
    )

    if assets_df.empty:
        st.info("No registered assets found. Go to 'Add New Asset' to register one!")
        return
    equip_by_asset = (
        {aid: grp.to_dict("records") for aid, grp in equip_df.groupby("asset_id")}
        if not equip_df.empty else {}
    )

    # Search bar & Filters
    col_search, col_filter = st.columns([2, 1])
    with col_search:
        search_query = st.text_input("Search Assets", placeholder="Search by Code, Manufacturer, Model, or Serial...")
    with col_filter:
        cat_filter = st.selectbox("Category Filter", ["All", "Lathe", "Mill", "Swiss", "QC", "Support", "Other"])

    filtered_assets = []
    for _, row in assets_df.iterrows():
        code         = row["asset_code"] or ""
        manufacturer = row["manufacturer"] or ""
        model_val    = row["model"] or ""
        serial       = row["serial_number"] or ""
        category     = row["equipment_category"] or "Other"
        build_year   = str(row["build_year"]) if row["build_year"] else ""
        control      = row["control_type"] or ""
        distributor  = row["distributor"] or ""

        match_str = f"{code} {manufacturer} {model_val} {serial} {category} {control}".lower()
        if search_query.lower() in match_str:
            if cat_filter == "All" or category == cat_filter:
                b1_interval = row["battery_1_interval"]
                has_battery = bool(row["battery_1_desc"]) and b1_interval is not None and int(b1_interval) > 0
                filtered_assets.append({
                    "asset_id":         row["asset_id"],
                    "code":             code,
                    "manufacturer":     manufacturer,
                    "model":            model_val,
                    "serial":           serial,
                    "category":         category,
                    "build_year":       build_year,
                    "control":          control,
                    "distributor":      distributor,
                    "distributor_email": row["distributor_email"] or "N/A",
                    "distributor_phone": row["distributor_phone"] or "N/A",
                    "vendor_contacts":  row["vendor_contacts"] or "None",
                    "has_battery":      has_battery,
                    "battery_desc":     row["battery_1_desc"],
                    "battery_interval": b1_interval,
                    "has_eq":           row["eq_count"] > 0,
                    "equipment":        equip_by_asset.get(row["asset_id"], []),
                    "report_count":     row["report_count"],
                })

    st.write(f"Showing **{len(filtered_assets)}** of **{len(assets_df)}** registered assets:")
    
    # Display List
    for a in filtered_assets:
        final_reports_count = int(a["report_count"])
        
        # Determine battery replacement notice.
        # Keep this on a single line with no leading indentation: a blank/indented
        # line here would close the card's HTML block and Streamlit would render
        # the markup as an indented code block instead of styled HTML.
        battery_notice = ""
        if a["has_battery"]:
            battery_notice = (
                f'<div class="battery-alert"><strong>Battery Tracked:</strong> '
                f"{a['battery_desc']} (Interval: {a['battery_interval']} days)</div>"
            )

        st.markdown(f"""
        <div class="asset-item">
            <div style="float: right; color: var(--text-muted); font-weight: 500; font-size: 0.9rem;">
                {a['category']}
            </div>
            <div class="asset-title">{a['manufacturer']} {a['model']} ({a['code']})</div>
            <div>
                {theme.badge(f"SN: {a['serial']}", "info")}
                {theme.badge(f"Control: {a['control']}", "primary")}
                {theme.badge(f"Reports: {final_reports_count}", "success")}
            </div>
            {battery_notice}
        </div>
        """, unsafe_allow_html=True)
        
        # Expanding details drawer
        with st.expander(f"Show Detailed Specification for {a['code']}"):
            detail_col1, detail_col2 = st.columns(2)
            with detail_col1:
                st.markdown(f"""
                **Manufacturer:** {a['manufacturer']}
                **Model:** {a['model']}
                **Serial Number:** {a['serial']}
                **Build Year:** {a['build_year']}
                **Control System:** {a['control']}
                """)
            with detail_col2:
                st.markdown(f"""
                **Distributor:** {a['distributor']}
                **Distributor Email:** {a['distributor_email']}
                **Distributor Phone:** {a['distributor_phone']}
                **Vendor Contacts:** {a['vendor_contacts']}
                """)

            # Additional equipment sub-view
            if a["has_eq"]:
                st.markdown("---")
                st.markdown("**Sub-Equipment Linked:**")
                for eq in a["equipment"]:
                    st.markdown(f"- **{eq['name']}** | Make: {eq['make'] or 'N/A'} | Model: {eq['model'] or 'N/A'} | SN: {eq['serial_number'] or 'N/A'}")
                        
            # Service reports history from DB
            if final_reports_count > 0:
                st.markdown("---")
                st.markdown("**Finalized Maintenance History:**")
                rpts_df = pd.read_sql_query(
                    "SELECT service_id, finalized_at FROM service_reports "
                    "WHERE asset_id = %%(aid)s AND record_state = 'Final' "
                    "ORDER BY finalized_at DESC",
                    engine,
                    params={"aid": a["asset_id"]}
                )
                for _, rpt in rpts_df.iterrows():
                    fin_date = rpt["finalized_at"].strftime("%%Y-%%m-%%d") if rpt["finalized_at"] is not None else "N/A"
                    st.markdown(f"`{rpt['service_id']}` (Date completed: {fin_date})")

        # Edit / Delete actions
        btn_edit, btn_del, _ = st.columns([1, 1, 5])
        with btn_edit:
            if st.button("Edit", key=f"edit_{a['asset_id']}", use_container_width=True):
                st.session_state.edit_asset_id = a["asset_id"]
                _set_page("Edit Asset")
                st.rerun()
        with btn_del:
            if st.button("Delete", key=f"del_{a['asset_id']}", use_container_width=True):
                st.session_state.pending_delete_asset = a["asset_id"]
                st.rerun()

        if st.session_state.get("pending_delete_asset") == a["asset_id"]:
            st.warning(f"Delete **{a['asset_id']}** permanently?")
            cc1, cc2 = st.columns(2)
            with cc1:
                if st.button("Yes, Delete", key=f"confirm_del_{a['asset_id']}"):
                    with engine.connect() as conn:
                        conn.execute(text("DELETE FROM asset_peripheral_equipment WHERE asset_id = :id"), {"id": a["asset_id"]})
                        conn.execute(text("DELETE FROM asset_batteries WHERE asset_id = :id"), {"id": a["asset_id"]})
                        conn.execute(text("DELETE FROM assets WHERE asset_id = :id"), {"id": a["asset_id"]})
                        conn.commit()
                    st.session_state.pop("pending_delete_asset", None)
                    st.rerun()
            with cc2:
                if st.button("Cancel", key=f"cancel_del_{a['asset_id']}"):
                    st.session_state.pop("pending_delete_asset", None)
                    st.rerun()

        st.markdown("<hr style='border-color: var(--bg-muted); margin: 8px 0;'>", unsafe_allow_html=True)

# -----------------------------------------------------------------------------
# PAGE 4: SERVICE REPORTS (DRAFTS & FINALIZATION WORKFLOW)
# -----------------------------------------------------------------------------
def render_service_page():
    st.markdown('<div class="gradient-header">Service Reports Manager</div>', unsafe_allow_html=True)

    engine = _require_db()
    if engine is None:
        return

    # Sub navigation selector with default handling
    if "service_page" not in st.session_state:
        st.session_state.service_page = "Dashboard Overview"
    options = ["Dashboard Overview", "Create Service Draft", "Edit Existing Draft", "Finalize Service Draft"]
    selected_index = 0
    if st.session_state.service_page in options:
        selected_index = options.index(st.session_state.service_page)
    st.session_state.service_page = st.selectbox(
        "Service Action",
        options,
        index=selected_index
    )

    subpage = st.session_state.service_page

    # Load registered assets from PostgreSQL (source of truth)
    with engine.connect() as _c:
        _asset_rows = _c.execute(
            text("SELECT asset_code, display_name FROM assets ORDER BY asset_code")
        ).fetchall()
    registered_assets = [
        {"code": r[0], "label": r[1] or r[0]}
        for r in _asset_rows
    ]

    # -------------------------------------
    # SUBPAGE A: SERVICE OVERVIEW
    # -------------------------------------
    if subpage == "Dashboard Overview":
        with engine.connect() as _c:
            _draft_count = _c.execute(
                text("SELECT COUNT(*) FROM service_reports WHERE record_state = 'Draft'")
            ).scalar()
        st.markdown(_metric_card("Total Open Drafts", _draft_count, card_style="max-width: 320px"), unsafe_allow_html=True)

        drafts_df = pd.read_sql_query(
            "SELECT report_id, asset_code, service_type, created_at "
            "FROM service_reports WHERE record_state = 'Draft' ORDER BY created_at DESC",
            engine
        )
        if not drafts_df.empty:
            st.markdown("### Open Draft Records")
            for _, d in drafts_df.iterrows():
                stype = d["service_type"] or "Unknown type"
                col_d1, col_d2 = st.columns([4, 1])
                with col_d1:
                    st.markdown(f"**{d['asset_code']}** — {stype}")
                with col_d2:
                    if st.button("Edit", key=f"edit_dr_{int(d['report_id'])}"):
                        st.session_state.selected_draft_id = int(d["report_id"])
                        st.session_state.service_page = "Edit Existing Draft"
                        st.rerun()
        else:
            st.info("All drafts are finalized. Click 'Create Service Draft' to begin a new record!")

    # -------------------------------------
    # SUBPAGE B: CREATE DRAFT
    # -------------------------------------
    elif subpage == "Create Service Draft":
        st.subheader("Create New Service Draft")

        if not registered_assets:
            st.warning("You must register at least one asset before creating service drafts.")
            return

        selected_asset = st.selectbox(
            "Select Target Asset",
            registered_assets,
            format_func=lambda a: f"{a['code']} — {a['label']}"
        )

        service_type = st.selectbox(
            "Service Type / Classification",
            ["Preventive", "Corrective", "Emergency"]
        )

        asset_code = selected_asset["code"]

        if st.button("Create Draft Record", use_container_width=True):
            with engine.connect() as _c:
                existing = _c.execute(
                    text("SELECT 1 FROM service_reports WHERE asset_code = :code AND record_state = 'Draft'"),
                    {"code": asset_code}
                ).fetchone()
            if existing:
                st.error(f"A work draft already exists for asset '{asset_code}'! Edit the existing draft or finalize it.")
            else:
                try:
                    with engine.connect() as _c:
                        _c.execute(text("""
                            INSERT INTO service_reports
                                (asset_id, asset_code, record_state, service_type, entry_timestamp)
                            VALUES (:aid, :code, 'Draft', :stype, NOW())
                        """), {"aid": f"A-{asset_code}", "code": asset_code, "stype": service_type})
                        _c.commit()
                    st.success(f"Created service draft for asset {asset_code}!")
                    st.session_state.service_page = "Edit Existing Draft"
                    st.rerun()
                except Exception as e:
                    _m = str(getattr(e, "orig", e)).lower()
                    if "uq_one_open_draft" in _m or "duplicate key" in _m or "unique" in _m:
                        st.error(f"A work draft already exists for asset '{asset_code}'! Edit the existing draft or finalize it.")
                    else:
                        st.error(f"Failed to create draft: {e}")

    # -------------------------------------
    # SUBPAGE C: EDIT DRAFT
    # -------------------------------------
    elif subpage == "Edit Existing Draft":
        st.subheader("Edit Work-in-Progress Service Draft")

        drafts_df = pd.read_sql_query(
            "SELECT report_id, asset_code, service_type, created_at "
            "FROM service_reports WHERE record_state = 'Draft' ORDER BY created_at DESC",
            engine
        )
        if drafts_df.empty:
            st.warning("No drafts are currently open.")
            return

        default_idx = 0
        sel_id = st.session_state.get("selected_draft_id")
        if sel_id:
            ids = drafts_df["report_id"].tolist()
            if sel_id in ids:
                default_idx = ids.index(sel_id)

        def _draft_label(row):
            ts = row["created_at"].strftime("%Y-%m-%d") if row["created_at"] is not None else "N/A"
            return f"{row['asset_code']} — {row['service_type'] or 'No type'} (created {ts})"

        options_list = [(int(row["report_id"]), _draft_label(row)) for _, row in drafts_df.iterrows()]
        selected_opt = st.selectbox(
            "Select Draft to Modify",
            options_list,
            index=default_idx,
            format_func=lambda x: x[1],
            key="draft_selector"
        )
        report_id = selected_opt[0]

        draft_df = pd.read_sql_query(
            "SELECT * FROM service_reports WHERE report_id = %(rid)s",
            engine,
            params={"rid": report_id}
        )
        if draft_df.empty:
            st.error("Draft not found.")
            return
        draft = draft_df.iloc[0]

        problem   = st.text_area("Problem / Fault Description",     value=draft["problem_description"] or "")
        work_done = st.text_area("Action Taken / Work Performed",    value=draft["work_performed"] or "")

        issue_opts = ["", "Mechanical", "Electrical", "Pneumatic", "Hydraulic",
                      "Software", "Operator / Process", "Other", "Unknown"]
        cause_opts = ["", "Wear", "Misalignment", "Contamination", "Electrical Fault",
                      "Software / Parameters", "Installation Error", "Damage", "Unknown"]

        col_cls1, col_cls2 = st.columns(2)
        with col_cls1:
            _ic_val   = draft.get("issue_category") or ""
            issue_idx = issue_opts.index(_ic_val) if _ic_val in issue_opts else 0
            issue_category = st.selectbox("Issue Category", issue_opts, index=issue_idx,
                                          format_func=lambda x: x or "— Not set —")
        with col_cls2:
            _rc_val   = draft.get("root_cause") or ""
            cause_idx = cause_opts.index(_rc_val) if _rc_val in cause_opts else 0
            root_cause = st.selectbox("Root Cause", cause_opts, index=cause_idx,
                                      format_func=lambda x: x or "— Not set —")

        col_inp1, col_inp2 = st.columns(2)
        with col_inp1:
            downtime_val = float(draft["downtime_hours"]) if draft["downtime_hours"] is not None else 0.0
            downtime = st.number_input("Downtime (Hours)", min_value=0.0, value=downtime_val, step=0.5)
            _rts_val = draft["return_to_service"]
            rts_idx  = {"Yes": 1, "No": 2}.get(_rts_val, 0)
            return_to_service = st.selectbox("Return To Service?", ["Pending", "Yes", "No"], index=rts_idx)
        with col_inp2:
            verified_by = st.text_input("Report Compiled / Verified By", value=draft["verified_by"] or "")

        col_btn1, col_btn2, col_btn3 = st.columns([1, 1, 1])
        with col_btn1:
            if st.button("Save Changes to Draft", use_container_width=True):
                with engine.connect() as _c:
                    _c.execute(text("""
                        UPDATE service_reports SET
                            issue_category      = :ic,
                            root_cause          = :rc,
                            problem_description = :prob,
                            work_performed      = :work,
                            downtime_hours      = :dt,
                            return_to_service   = :rts,
                            verified_by         = :vb,
                            updated_at          = NOW()
                        WHERE report_id = :id
                    """), {
                        "ic":   issue_category or None,
                        "rc":   root_cause or None,
                        "prob": problem.strip(),
                        "work": work_done.strip(),
                        "dt":   downtime,
                        "rts":  return_to_service,
                        "vb":   verified_by.strip(),
                        "id":   report_id,
                    })
                    _c.commit()
                st.success("Draft saved successfully!")

        with col_btn2:
            if st.button("Finalize This Draft", use_container_width=True):
                st.session_state.service_page = "Finalize Service Draft"
                st.session_state.selected_draft_id = report_id
                st.rerun()

        with col_btn3:
            if st.button("Delete Draft", use_container_width=True, key="delete_draft_btn"):
                st.session_state.show_delete_confirmation = True

        if st.session_state.get("show_delete_confirmation", False):
            st.warning(f"You are about to delete this draft for **{draft['asset_code']}**. This cannot be undone.")
            col_confirm1, col_confirm2 = st.columns(2)
            with col_confirm1:
                if st.button("Delete Permanently", use_container_width=True, key="confirm_delete"):
                    try:
                        with engine.connect() as _c:
                            _c.execute(text("DELETE FROM service_reports WHERE report_id = :id"), {"id": report_id})
                            _c.commit()
                        st.session_state.show_delete_confirmation = False
                        st.session_state.selected_draft_id = None
                        st.success("Draft deleted successfully!")
                        st.session_state.service_page = "Dashboard Overview"
                        st.rerun()
                    except Exception as e:
                        st.error(f"Error deleting draft: {e}")
                        st.session_state.show_delete_confirmation = False
            with col_confirm2:
                if st.button("Cancel", use_container_width=True, key="cancel_delete"):
                    st.session_state.show_delete_confirmation = False
                    st.rerun()

        # ── Parts used on this draft ──────────────────────────────────────────
        st.divider()
        st.markdown("##### Parts Used")

        parts_df = pd.read_sql_query(
            "SELECT id, part_name, quantity, is_battery FROM service_parts "
            "WHERE report_id = %(rid)s ORDER BY id",
            engine,
            params={"rid": report_id}
        )
        if parts_df.empty:
            st.caption("No parts recorded for this draft yet.")
        else:
            for _, prow in parts_df.iterrows():
                pc1, pc2, pc3, pc4 = st.columns([5, 1, 2, 1])
                pc1.write(prow["part_name"])
                pc2.write(f"× {int(prow['quantity'])}")
                pc3.write("Battery" if prow["is_battery"] else "Part")
                if pc4.button("", key=f"del_part_{int(prow['id'])}"):
                    with engine.connect() as _c:
                        _c.execute(text("DELETE FROM service_parts WHERE id = :pid"),
                                   {"pid": int(prow["id"])})
                        _c.commit()
                    st.rerun()

        with st.form(f"add_part_form_{report_id}", clear_on_submit=True):
            ap1, ap2, ap3 = st.columns([5, 1, 2])
            new_part_name = ap1.text_input("Part name")
            new_part_qty  = ap2.number_input("Qty", min_value=1, value=1, step=1)
            new_part_batt = ap3.checkbox("Battery replacement")
            if st.form_submit_button("Add Part", use_container_width=True):
                if new_part_name.strip():
                    with engine.connect() as _c:
                        _c.execute(text("""
                            INSERT INTO service_parts (report_id, part_name, quantity, is_battery)
                            VALUES (:rid, :name, :qty, :batt)
                        """), {
                            "rid":  report_id,
                            "name": new_part_name.strip(),
                            "qty":  int(new_part_qty),
                            "batt": bool(new_part_batt),
                        })
                        _c.commit()
                    st.rerun()
                else:
                    st.warning("Enter a part name before adding.")

    # -------------------------------------
    # SUBPAGE D: FINALIZE SERVICE REPORT
    # -------------------------------------
    elif subpage == "Finalize Service Draft":
        st.subheader("Lock & Finalize Service Record")

        drafts_df = pd.read_sql_query(
            "SELECT report_id, asset_code, service_type, created_at "
            "FROM service_reports WHERE record_state = 'Draft' ORDER BY created_at DESC",
            engine
        )
        if drafts_df.empty:
            st.warning("No drafts are currently open.")
            return

        default_idx = 0
        sel_id = st.session_state.get("selected_draft_id")
        if sel_id:
            ids = drafts_df["report_id"].tolist()
            if sel_id in ids:
                default_idx = ids.index(sel_id)

        options_list = [(int(row["report_id"]), f"{row['asset_code']} — {row['service_type'] or 'No type'}") for _, row in drafts_df.iterrows()]
        selected_opt = st.selectbox(
            "Select Draft to Finalize",
            options_list,
            index=default_idx,
            format_func=lambda x: x[1],
            key="finalize_draft_selector"
        )
        report_id = selected_opt[0]

        draft_df = pd.read_sql_query(
            "SELECT * FROM service_reports WHERE report_id = %(rid)s",
            engine,
            params={"rid": report_id}
        )
        if draft_df.empty:
            st.error("Draft not found.")
            return
        draft = draft_df.iloc[0]

        asset_code = draft["asset_code"] or ""
        prob       = draft["problem_description"] or ""
        work       = draft["work_performed"] or ""
        dt_val     = draft["downtime_hours"] or 0.0
        verifier   = draft["verified_by"] or ""
        issue_cat  = draft.get("issue_category") or "—"
        root_c     = draft.get("root_cause") or "—"

        st.info("Please review all service details. Finalization locks this record as an immutable historical record.")
        st.markdown(f"""
        **Review Details:**
        - **Asset Code:** `{asset_code}`
        - **Issue Category:** {issue_cat}
        - **Root Cause:** {root_c}
        - **Problem Description:** {prob}
        - **Work Performed:** {work}
        - **Downtime Hours:** {dt_val} hours
        - **Verified By:** {verifier}
        """)

        fin_parts = pd.read_sql_query(
            "SELECT part_name, quantity, is_battery FROM service_parts "
            "WHERE report_id = %(rid)s ORDER BY id",
            engine,
            params={"rid": report_id}
        )
        if not fin_parts.empty:
            parts_lines = "\n".join(
                f"- {pr['part_name']} × {int(pr['quantity'])}" + (" (battery)" if pr["is_battery"] else "")
                for _, pr in fin_parts.iterrows()
            )
            st.markdown(f"**Parts Used:**\n{parts_lines}")

        if not verifier.strip():
            st.warning("**Verified By** is a required field. Go back to 'Edit Existing Draft' and fill it in before finalization!")
            return

        if draft["return_to_service"] not in ("Yes", "No"):
            st.warning("**Return To Service** must be set to Yes or No. Go back to 'Edit Existing Draft' and set it before finalization!")
            return

        st.warning("**Warning**: Finalization is permanent and cannot be undone.")

        if st.button("Lock & Finalize Record", use_container_width=True):
            service_date = datetime.now().strftime("%Y%m%d")
            try:
                with engine.connect() as _c:
                    seq_num = 1
                    while True:
                        final_id = f"S-{asset_code}-{service_date}-{str(seq_num).zfill(3)}"
                        exists = _c.execute(
                            text("SELECT 1 FROM service_reports WHERE service_id = :sid"),
                            {"sid": final_id}
                        ).fetchone()
                        if not exists:
                            break
                        seq_num += 1

                    _c.execute(text("""
                        UPDATE service_reports SET
                            service_id   = :sid,
                            record_state = 'Final',
                            finalized_at = NOW(),
                            updated_at   = NOW()
                        WHERE report_id = :id
                    """), {"sid": final_id, "id": report_id})
                    _c.commit()

                st.success(f"Service finalized successfully! Record ID: `{final_id}`")
                st.balloons()
                st.session_state.service_page = "Dashboard Overview"
                st.session_state.selected_draft_id = None
                st.rerun()
            except Exception as e:
                st.error(f"Error finalizing service report: {e}")


# -----------------------------------------------------------------------------
# PAGE 5: ERP SHOP DASHBOARD
# -----------------------------------------------------------------------------
def render_erp_dashboard_page():
    st.markdown('<div class="gradient-header">ERP Shop Dashboard</div>', unsafe_allow_html=True)

    engine = _require_db()
    if engine is None:
        return

    # Navigation tabs
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "Shop Floor Live View", 
        "Financial Job Costing", 
        "Capacity & Backlog", 
        "Scrap & Quality", 
        "SQL Integration Guide"
    ])
    
    # -----------------------------------------
    # TAB 1: LIVE VIEW
    # -----------------------------------------
    with tab1:
        st.subheader("CNC Machining Centers - Active Operations")
        
        df_live = pd.read_sql_query("""
            SELECT lt.ticket_id    AS "TicketID",
                   lt.job_no       AS "JobNo",
                   j.part_no       AS "PartNo",
                   j.customer      AS "Customer",
                   wc.machine_id   AS "MachineID",
                   wc.machine_name AS "MachineName",
                   wc.department   AS "Department",
                   emp.name        AS "OperatorName",
                   lt.op_code      AS "OpCode",
                   lt.op_desc      AS "OpDesc",
                   TO_CHAR(lt.time_in, 'YYYY-MM-DD HH24:MI:SS') AS "TimeIn"
            FROM labor_tickets lt
            JOIN jobs j         ON lt.job_no      = j.job_no
            JOIN work_centers wc ON lt.machine_id = wc.machine_id
            JOIN employees emp  ON lt.employee_id = emp.employee_id
            WHERE lt.time_out IS NULL
        """, engine)
        
        if df_live.empty:
            st.info("No active check-ins on the shop floor right now.")
        else:
            col_live1, col_live2 = st.columns([3, 1])
            with col_live1:
                # Live grid of active machines
                cols = st.columns(3)
                for index, row in df_live.iterrows():
                    col_idx = index % 3
                    with cols[col_idx]:
                        # Glassmorphism Active Card
                        color_border = theme.department_color(row['Department'])
                        st.markdown(f"""
                        <div class="asset-item" style="border-left-color: {color_border}; background-color: var(--surface);">
                            <div style="float: right;">
                                <span class="status-badge"><span class="status-pulse"></span>ACTIVE</span>
                            </div>
                            <div style="font-weight: 700; font-size: 1.1rem; color: var(--text);">{row['MachineID']} - {row['MachineName']}</div>
                            <div style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 12px; font-weight: 600; text-transform: uppercase;">{row['Department']} Center</div>
                            <hr style="margin: 8px 0; border-color: var(--bg-muted);">
                            <div style="font-size: 0.9rem; margin-bottom: 4px;"><strong>Job Number:</strong> <code style="background-color: var(--bg-muted); padding: 2px 6px; border-radius: 4px;">{row['JobNo']}</code></div>
                            <div style="font-size: 0.9rem; margin-bottom: 4px;"><strong>Part Name:</strong> {row['PartNo']}</div>
                            <div style="font-size: 0.9rem; margin-bottom: 4px;"><strong>Customer:</strong> {row['Customer']}</div>
                            <div style="font-size: 0.9rem; margin-bottom: 4px;"><strong>Op:</strong> {row['OpCode']} - {row['OpDesc']}</div>
                            <div style="font-size: 0.9rem; margin-bottom: 4px;"><strong>Operator:</strong> {row['OperatorName']}</div>
                            <div style="font-size: 0.8rem; color: var(--text-subtle); margin-top: 8px;">Clocked In: {row['TimeIn']}</div>
                        </div>
                        """, unsafe_allow_html=True)
            with col_live2:
                lathes = len(df_live[df_live['Department'] == 'Lathe'])
                mills  = len(df_live[df_live['Department'] == 'Mill'])
                swiss  = len(df_live[df_live['Department'] == 'Swiss'])
                st.markdown(_metric_card(
                    "Active Running CNCs", len(df_live),
                    footer=f"Lathes: {lathes} | Mills: {mills} | Swiss: {swiss}"
                ), unsafe_allow_html=True)
                
                st.subheader("Live Dispatch Board")
                st.dataframe(
                    df_live[['MachineID', 'JobNo', 'OperatorName', 'OpDesc', 'TimeIn']],
                    use_container_width=True,
                    hide_index=True
                )
                
    # -----------------------------------------
    # TAB 2: FINANCIAL JOB COSTING
    # -----------------------------------------
    with tab2:
        st.subheader("Financial Variance - Estimated vs Actual Labor Hours")
        
        df_cost = pd.read_sql_query("""
            SELECT j.job_no          AS "JobNo",
                   j.customer        AS "Customer",
                   j.part_no         AS "PartNo",
                   j.order_qty       AS "OrderQty",
                   j.due_date        AS "DueDate",
                   j.est_setup_hours AS "EstSetupHours",
                   j.est_run_hours   AS "EstRunHours",
                   j.status          AS "Status",
                   COALESCE(SUM(lt.setup_hours), 0) AS "ActSetupHours",
                   COALESCE(SUM(lt.run_hours),   0) AS "ActRunHours"
            FROM jobs j
            LEFT JOIN labor_tickets lt ON j.job_no = lt.job_no
            GROUP BY j.job_no, j.customer, j.part_no, j.order_qty, j.due_date,
                     j.est_setup_hours, j.est_run_hours, j.status
        """, engine)
        
        # Calculate derived columns
        df_cost['EstTotalHours'] = df_cost['EstSetupHours'] + df_cost['EstRunHours']
        df_cost['ActTotalHours'] = df_cost['ActSetupHours'] + df_cost['ActRunHours']
        df_cost['VarianceHours'] = df_cost['ActTotalHours'] - df_cost['EstTotalHours']
        df_cost['PctOverrun'] = (df_cost['ActTotalHours'] / df_cost['EstTotalHours'] - 1) * 100
        df_cost['PctOverrun'] = df_cost['PctOverrun'].replace([float('inf'), float('-inf')], 0).fillna(0)
        
        # User interactive filter threshold
        overrun_filter = st.slider("Filter: Highlight Job Overrun Threshold (%)", min_value=0, max_value=100, value=25)
        
        # Display cards
        total_overrun_jobs = len(df_cost[(df_cost['PctOverrun'] > overrun_filter) & (df_cost['Status'] == 'Completed')])
        
        total_est    = df_cost[df_cost['Status'] == 'Completed']['EstTotalHours'].sum()
        total_act    = df_cost[df_cost['Status'] == 'Completed']['ActTotalHours'].sum()
        net_variance = total_act - total_est

        col_c1, col_c2, col_c3 = st.columns(3)
        with col_c1:
            st.markdown(_metric_card("Jobs Completed", len(df_cost[df_cost['Status'] == 'Completed'])), unsafe_allow_html=True)
        with col_c2:
            alert_card  = "border-color: var(--danger)" if total_overrun_jobs > 0 else ""
            alert_value = theme.value_gradient("danger") if total_overrun_jobs > 0 else ""
            st.markdown(_metric_card("Critical Overrun Alerts", total_overrun_jobs, card_style=alert_card, value_style=alert_value), unsafe_allow_html=True)
        with col_c3:
            var_style = (
                theme.value_gradient("danger") if net_variance > 0
                else theme.value_gradient("success")
            )
            st.markdown(_metric_card("Net Hours Variance", f"{net_variance:+.1f} hrs", value_style=var_style), unsafe_allow_html=True)
            
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Split layout
        col_chart, col_table = st.columns([1, 1])
        
        with col_chart:
            st.subheader("Est. vs Act. Labor Hours Comparison")
            # Build horizontal side-by-side bar chart
            fig = go.Figure()
            completed_df = df_cost[df_cost['Status']=='Completed'].sort_values('JobNo')
            fig.add_trace(go.Bar(
                y=completed_df['JobNo'],
                x=completed_df['EstTotalHours'],
                name='Estimated Hours',
                orientation='h',
                marker_color=theme.PALETTE["border-soft"]
            ))
            fig.add_trace(go.Bar(
                y=completed_df['JobNo'],
                x=completed_df['ActTotalHours'],
                name='Actual Hours',
                orientation='h',
                marker_color=theme.PALETTE["info"]
            ))
            fig.update_layout(
                barmode='group',
                height=450,
                margin=dict(l=50, r=20, t=10, b=10),
                legend=dict(orientation="h", y=1.05, x=0.5, xanchor="center")
            )
            st.plotly_chart(fig, use_container_width=True)
            
        with col_table:
            st.subheader("Job Ledger Details")
            
            # Format and styled dataframe representation
            styled_df = df_cost[['JobNo', 'Customer', 'PartNo', 'EstTotalHours', 'ActTotalHours', 'VarianceHours', 'PctOverrun', 'Status']].copy()
            styled_df['EstTotalHours'] = styled_df['EstTotalHours'].round(1)
            styled_df['ActTotalHours'] = styled_df['ActTotalHours'].round(1)
            styled_df['VarianceHours'] = styled_df['VarianceHours'].round(1)
            styled_df['PctOverrun'] = styled_df['PctOverrun'].apply(lambda x: f"{x:+.0f}%" if x != 0 else "0%")
            
            st.dataframe(
                styled_df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "VarianceHours": st.column_config.NumberColumn(
                        "Variance (Hrs)",
                        format="%+f"
                    ),
                    "PctOverrun": "Overrun %"
                }
            )
            
    # -----------------------------------------
    # TAB 3: CAPACITY & BACKLOG
    # -----------------------------------------
    with tab3:
        st.subheader("Machine Center Backlog Capacity")
        
        df_back = pd.read_sql_query("""
            SELECT COALESCE(wc.department, 'Unassigned')   AS "Department",
                   COALESCE(wc.machine_name, 'Unassigned') AS "MachineName",
                   SUM(j.est_setup_hours + j.est_run_hours) AS "BacklogHours",
                   COUNT(j.job_no) AS "JobCount"
            FROM jobs j
            LEFT JOIN work_centers wc ON wc.machine_id = (
               SELECT lt.machine_id FROM labor_tickets lt
               WHERE lt.job_no = j.job_no AND lt.op_code = '30' LIMIT 1
            )
            WHERE j.status IN ('Active', 'Scheduled')
            GROUP BY COALESCE(wc.machine_name, 'Unassigned'),
                     COALESCE(wc.department, 'Unassigned')
        """, engine)
        
        if df_back.empty:
            st.info("No active backlog scheduled on the floor.")
        else:
            col_b1, col_b2 = st.columns([1, 1])
            
            with col_b1:
                st.subheader("Hours Backlog by Machining Center")
                fig_back = px.bar(
                    df_back.sort_values('BacklogHours', ascending=False),
                    x='BacklogHours',
                    y='MachineName',
                    color='Department',
                    color_discrete_map=theme.DEPARTMENT_COLORS,
                    orientation='h',
                    labels={'BacklogHours': 'Queued Hours', 'MachineName': 'Machine'},
                    height=450
                )
                fig_back.update_layout(margin=dict(l=50, r=20, t=10, b=10))
                st.plotly_chart(fig_back, use_container_width=True)
                
            with col_b2:
                st.subheader("Backlog Capacity Summary Table")
                st.dataframe(
                    df_back.sort_values('BacklogHours', ascending=False),
                    use_container_width=True,
                    hide_index=True
                )
                
                # Dynamic backlog planning insight card
                total_hours = df_back['BacklogHours'].sum()
                fleet_size = pd.read_sql_query("SELECT COUNT(*) AS n FROM work_centers", engine)["n"].iloc[0]
                fleet_size = max(int(fleet_size), 1)
                st.markdown(f"""
                <div class="asset-item" style="border-left-color: var(--dept-lathe); background-color: var(--surface); margin-top: 25px;">
                    <div class="asset-title">Production Scheduling Insight</div>
                    <div style="font-size: 0.925rem; color: var(--text-strong); line-height: 1.5;">
                        Your shop floor is currently holding a total backlog of <strong>{total_hours:.1f} hours</strong> of estimated production. 
                        Assuming a standard <strong>1-shift 8-hour operation</strong> per machine day, this represents approximately 
                        <strong>{(total_hours / fleet_size / 8):.1f} days</strong> of load across your entire {fleet_size} CNC Work Center fleet.
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
    # -----------------------------------------
    # TAB 4: SCRAP & QUALITY
    # -----------------------------------------
    with tab4:
        st.subheader("Scrap Rate Analysis & First-Pass Yield (FPY)")
        
        df_scrap = pd.read_sql_query("""
            SELECT lt.machine_id   AS "MachineID",
                   wc.machine_name AS "MachineName",
                   wc.department   AS "Department",
                   SUM(lt.qty_good)  AS "TotalGood",
                   SUM(lt.qty_scrap) AS "TotalScrap"
            FROM labor_tickets lt
            JOIN work_centers wc ON lt.machine_id = wc.machine_id
            WHERE lt.op_code = '30'
            GROUP BY lt.machine_id, wc.machine_name, wc.department
        """, engine)
        
        if df_scrap.empty or df_scrap['TotalScrap'].sum() == 0:
            st.info("Excellent quality performance! There is no scrap recorded in this database cycle.")
        else:
            total_good = df_scrap['TotalGood'].sum()
            total_scrap = df_scrap['TotalScrap'].sum()
            overall_scrap_rate = (total_scrap / (total_good + total_scrap)) * 100
            fpy = 100 - overall_scrap_rate
            
            col_s1, col_s2, col_s3 = st.columns(3)
            with col_s1:
                st.markdown(_metric_card("Total Parts Produced", int(total_good + total_scrap)), unsafe_allow_html=True)
            with col_s2:
                st.markdown(_metric_card("Total Scrap Parts", int(total_scrap), value_style=theme.value_gradient("danger")), unsafe_allow_html=True)
            with col_s3:
                st.markdown(_metric_card("Shop First-Pass Yield (FPY)", f"{fpy:.1f}%", value_style=theme.value_gradient("success")), unsafe_allow_html=True)
                
            st.markdown("<br>", unsafe_allow_html=True)
            
            col_sc1, col_sc2 = st.columns([1, 1])
            with col_sc1:
                st.subheader("Scrap Pieces by Machining Department")
                df_dept_scrap = df_scrap.groupby('Department')['TotalScrap'].sum().reset_index()
                fig_scrap_pie = px.pie(
                    df_dept_scrap,
                    values='TotalScrap',
                    names='Department',
                    color='Department',
                    color_discrete_map=theme.DEPARTMENT_COLORS,
                    hole=0.4
                )
                fig_scrap_pie.update_layout(margin=dict(l=20, r=20, t=10, b=10))
                st.plotly_chart(fig_scrap_pie, use_container_width=True)
                
            with col_sc2:
                st.subheader("Scrap Rate List by Machine Center")
                df_scrap['ScrapRate'] = (df_scrap['TotalScrap'] / (df_scrap['TotalGood'] + df_scrap['TotalScrap'])) * 100
                st.dataframe(
                    df_scrap[['MachineName', 'Department', 'TotalGood', 'TotalScrap', 'ScrapRate']].sort_values('TotalScrap', ascending=False),
                    use_container_width=True,
                    hide_index=True,
                    column_config={
                        "ScrapRate": st.column_config.NumberColumn(
                            "Scrap Rate %",
                            format="%.1f%%"
                        )
                    }
                )
                
    # -----------------------------------------
    # TAB 5: SQL INTEGRATION GUIDE
    # -----------------------------------------
    with tab5:
        st.subheader("Connecting to on-premise ECI M1 / JobBoss SQL Server")
        st.markdown("""
        To connect this app to your actual live ECI M1 / JobBoss SQL Server instead of the local PostgreSQL database, replace the SQLAlchemy engine with a `pyodbc` connection helper.
        
        ### Prerequisites
        Install the SQL Server ODBC driver and standard python ODBC package:
        ```bash
        pip install pyodbc
        ```
        
        ### Python SQL Connection String
        """)
        
        st.code("""
import pyodbc
import pandas as pd

def get_jobboss_connection():
    # Configure your on-premise SQL Server credentials
    conn_str = (
        "Driver={ODBC Driver 17 for SQL Server};"
        "Server=192.168.1.50\\\\SQLEXPRESS;" # Your server name/IP & SQL instance
        "Database=JOBBOSS_DB;"                # Your production Database
        "UID=sa;"                             # SQL Server login username
        "PWD=CaseyMachine74;"                 # Password
        "Trusted_Connection=no;"
    )
    return pyodbc.connect(conn_str)

# Example function querying live check-ins directly from JobBoss
def get_live_labor_checkins():
    conn = get_jobboss_connection()
    
    # Example SQL Server schema for JobBoss/ECI M1 LaborTickets
    query = \"\"\"
    SELECT 
        lt.TICKET_ID as TicketID, 
        lt.JOB_NUMBER as JobNo, 
        j.PART_NUMBER as PartNo, 
        j.CUSTOMER_NAME as Customer, 
        wc.WORK_CENTER_ID as MachineID, 
        wc.DESCRIPTION as MachineName, 
        emp.FIRST_LAST_NAME as OperatorName, 
        lt.OP_CODE as OpCode, 
        lt.OP_DESCRIPTION as OpDesc, 
        lt.TIME_IN as TimeIn
    FROM LABOR_TICKET lt
    JOIN JOB_ORDER j ON lt.JOB_NUMBER = j.JOB_NUMBER
    JOIN WORK_CENTER wc ON lt.WORK_CENTER_ID = wc.WORK_CENTER_ID
    JOIN EMPLOYEE emp ON lt.EMPLOYEE_ID = emp.EMPLOYEE_ID
    WHERE lt.TIME_OUT IS NULL;
    \"\"\"
    
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df
        """, language="python")

# -----------------------------------------------------------------------------
# PAGE 6: REPORTING & ANALYTICS SUITE
# -----------------------------------------------------------------------------
# Real interactive reporting over the live base tables (no fact_reporting_production
# dependency). Replaces the old ETL/cookbook tabs. KPI rulings that bind every tab:
#   * Quality (parts / yield / scrap) filters op_code='30' — scrap is only logged
#     on the main machining op, so summing across ops would triple-count parts.
#   * Hours / utilization / labor-efficiency use ALL op_codes (setup + saw are
#     real labor).
#   * Every ratio guards its denominator with NULLIF -> renders "N/A", never inf.
#   * Maintenance analytics count record_state='Final' only and degrade to clean
#     empty-states while service_reports is unpopulated.

# QC / Support live only in work_centers (not in theme.DEPARTMENT_COLORS), so the
# map is extended here to keep them coloured in production charts.
_DEPT_MAP = {
    **theme.DEPARTMENT_COLORS,
    "QC":      theme.PALETTE["text-muted"],
    "Support": theme.PALETTE["text-subtle"],
}

# Export queries are shared between the per-view CSV buttons and the full
# workbook builder, so they live in one place.
_SQL_EXPORT = {
    "production_jobs": """
        SELECT j.job_no AS job, j.customer AS customer, j.part_no AS part,
               ROUND((j.est_setup_hours + j.est_run_hours)::numeric, 1)           AS est_hrs,
               ROUND(COALESCE(SUM(lt.setup_hours + lt.run_hours), 0)::numeric, 1) AS act_hrs,
               ROUND(COALESCE(SUM(lt.setup_hours + lt.run_hours), 0)
                     - (j.est_setup_hours + j.est_run_hours), 1)                  AS var_hrs,
               CASE WHEN COALESCE(SUM(lt.setup_hours + lt.run_hours), 0) > 0
                    THEN ROUND(100.0 * (j.est_setup_hours + j.est_run_hours)
                         / SUM(lt.setup_hours + lt.run_hours), 1)
               END                                                                AS efficiency
        FROM jobs j
        LEFT JOIN labor_tickets lt ON j.job_no = lt.job_no
        WHERE j.status = 'Completed'
        GROUP BY j.job_no, j.customer, j.part_no, j.est_setup_hours, j.est_run_hours
        ORDER BY efficiency ASC NULLS LAST
    """,
    "production_scrap": """
        SELECT wc.machine_name AS machine, wc.department AS department,
               COALESCE(SUM(lt.qty_good), 0)  AS good,
               COALESCE(SUM(lt.qty_scrap), 0) AS scrap,
               ROUND(100.0 * SUM(lt.qty_scrap)
                     / NULLIF(SUM(lt.qty_good) + SUM(lt.qty_scrap), 0), 1) AS scrap_pct
        FROM labor_tickets lt
        JOIN work_centers wc ON lt.machine_id = wc.machine_id
        WHERE lt.op_code = '30'
        GROUP BY wc.machine_name, wc.department
        ORDER BY scrap DESC
    """,
    "production_machine_load": """
        SELECT wc.machine_name AS machine, wc.department AS department,
               ROUND(COALESCE(SUM(lt.setup_hours), 0)::numeric, 1) AS setup_hrs,
               ROUND(COALESCE(SUM(lt.run_hours), 0)::numeric, 1)   AS run_hrs
        FROM labor_tickets lt
        JOIN work_centers wc ON lt.machine_id = wc.machine_id
        GROUP BY wc.machine_name, wc.department
        ORDER BY run_hrs DESC
    """,
    "service_reports_final": """
        SELECT service_id, asset_code, service_type, issue_category, root_cause,
               downtime_hours, return_to_service, verified_by, finalized_at
        FROM service_reports
        WHERE record_state = 'Final'
        ORDER BY finalized_at DESC NULLS LAST
    """,
    "service_parts": """
        SELECT sp.part_name, sp.quantity, sp.is_battery, sr.service_id, sr.asset_code
        FROM service_parts sp
        JOIN service_reports sr ON sp.report_id = sr.report_id
        WHERE sr.record_state = 'Final'
        ORDER BY sp.part_name
    """,
    "assets": """
        SELECT asset_code, equipment_category, department_code, display_name, manufacturer,
               model, serial_number, control_type, build_year, planned_pm_interval_days,
               asset_status, commission_date
        FROM assets
        ORDER BY asset_code
    """,
    "asset_batteries": """
        SELECT a.asset_code, b.battery_number, b.description, b.part_number,
               b.replacement_interval_days
        FROM asset_batteries b
        JOIN assets a ON a.asset_id = b.asset_id
        ORDER BY a.asset_code, b.battery_number
    """,
    "asset_peripherals": """
        SELECT a.asset_code, p.equip_number, p.name, p.make, p.model, p.serial_number
        FROM asset_peripheral_equipment p
        JOIN assets a ON a.asset_id = p.asset_id
        ORDER BY a.asset_code, p.equip_number
    """,
}

_SQL_SUMMARY = """
    SELECT
      (SELECT COALESCE(SUM(qty_good)  FILTER (WHERE op_code='30'), 0) FROM labor_tickets) AS good_op30,
      (SELECT COALESCE(SUM(qty_scrap) FILTER (WHERE op_code='30'), 0) FROM labor_tickets) AS scrap_op30,
      (SELECT ROUND(COALESCE(SUM(setup_hours + run_hours), 0)::numeric, 1) FROM labor_tickets) AS logged_hours,
      (SELECT COUNT(DISTINCT machine_id) FROM labor_tickets WHERE time_out IS NULL) AS active_machines,
      (SELECT COUNT(*) FROM service_reports WHERE record_state='Final') AS final_events,
      (SELECT COALESCE(SUM(downtime_hours), 0) FROM service_reports WHERE record_state='Final') AS total_downtime,
      (SELECT COUNT(*) FROM assets) AS total_assets,
      (SELECT COUNT(*) FILTER (WHERE planned_pm_interval_days IS NULL) FROM assets) AS assets_missing_pm
"""


# ── small shared helpers ──────────────────────────────────────────────────────
def _q(sql, engine, params=None):
    """Run a read query and return a DataFrame. Aggregation lives in SQL; pandas
    does only light shaping. Multiselect filters bind as Postgres arrays via
    ``col = ANY(:list)``, so an empty selection is coalesced to "all" first."""
    return pd.read_sql_query(text(sql), engine, params=params or {})


def _na(value, fmt="{:.1f}"):
    """Format a possibly-NULL/NaN numeric, or "N/A" when it is missing — used so a
    zero denominator never renders as a misleading 100% or ∞."""
    if value is None:
        return "N/A"
    try:
        if pd.isna(value):
            return "N/A"
    except (TypeError, ValueError):
        pass
    return fmt.format(value)


def _empty_state(title, body, icon=""):
    """Branded empty-section card so an empty view reads as designed, not broken."""
    st.markdown(
        f'<div class="asset-item" style="border-left-color: var(--border-soft); '
        f'background-color: var(--surface);"><div class="asset-title">{icon} {title}</div>'
        f'<div style="font-size:0.925rem;color:var(--text-muted);line-height:1.5;">{body}</div></div>',
        unsafe_allow_html=True,
    )


def _insight_card(title, body_html, accent="var(--dept-lathe)", margin_top="0"):
    """Left-accented call-out card carrying the "so what" narrative under a section."""
    st.markdown(
        f'<div class="asset-item" style="border-left-color: {accent}; '
        f'background-color: var(--surface); margin-top: {margin_top};">'
        f'<div class="asset-title">{title}</div>'
        f'<div style="font-size:0.925rem;color:var(--text-strong);line-height:1.5;">{body_html}</div></div>',
        unsafe_allow_html=True,
    )


def _hr():
    st.markdown("<hr style='border-color:var(--border);margin:14px 0 18px;'>", unsafe_allow_html=True)


def _pareto_fig(df, cat_col, val_col, y_title, bar_color):
    """Classic Pareto: bars sorted descending + cumulative-% line on a secondary axis."""
    d = df.copy()
    d[val_col] = pd.to_numeric(d[val_col])
    d = d.sort_values(val_col, ascending=False)
    total = float(d[val_col].sum())
    d["cum_pct"] = (d[val_col].cumsum() / total * 100) if total else 0.0
    fig = go.Figure()
    fig.add_trace(go.Bar(x=d[cat_col], y=d[val_col], marker_color=bar_color, name=y_title))
    fig.add_trace(go.Scatter(
        x=d[cat_col], y=d["cum_pct"], name="Cumulative %", yaxis="y2",
        mode="lines+markers", line=dict(color=theme.PALETTE["text-strong"])))
    fig.update_layout(
        height=400, margin=dict(l=40, r=50, t=30, b=60),
        legend=dict(orientation="h", y=1.12, x=0.5, xanchor="center"),
        yaxis=dict(title=y_title),
        yaxis2=dict(overlaying="y", side="right", range=[0, 100], ticksuffix="%", showgrid=False))
    return fig


def _build_full_report(engine):
    """Assemble the multi-sheet .xlsx workbook in memory and return its bytes."""
    snap = _q(_SQL_SUMMARY, engine).iloc[0]
    good, scrap = float(snap["good_op30"]), float(snap["scrap_op30"])
    fpy = round(100 * good / (good + scrap), 1) if (good + scrap) else None
    summary = pd.DataFrame([
        {"Metric": "First-Pass Yield % (op 30)", "Value": fpy if fpy is not None else "N/A"},
        {"Metric": "Good parts (op 30)",          "Value": int(good)},
        {"Metric": "Scrap parts (op 30)",         "Value": int(scrap)},
        {"Metric": "Logged machine hours",        "Value": float(snap["logged_hours"])},
        {"Metric": "Active machines (now)",       "Value": int(snap["active_machines"])},
        {"Metric": "Finalized service events",    "Value": int(snap["final_events"])},
        {"Metric": "Total downtime hrs",          "Value": float(snap["total_downtime"])},
        {"Metric": "Registered assets",           "Value": int(snap["total_assets"])},
        {"Metric": "Assets missing PM interval",  "Value": int(snap["assets_missing_pm"])},
        {"Metric": "Report generated",            "Value": str(datetime.now())},
    ])
    sheets = {
        "Summary":            summary,
        "Production_Jobs":    _q(_SQL_EXPORT["production_jobs"], engine),
        "Scrap_By_Machine":   _q(_SQL_EXPORT["production_scrap"], engine),
        "Machine_Logged_Hrs": _q(_SQL_EXPORT["production_machine_load"], engine),
        "Service_Reports":    _q(_SQL_EXPORT["service_reports_final"], engine),
        "Service_Parts":      _q(_SQL_EXPORT["service_parts"], engine),
        "Assets":             _q(_SQL_EXPORT["assets"], engine),
        "Asset_Batteries":    _q(_SQL_EXPORT["asset_batteries"], engine),
        "Asset_Peripherals":  _q(_SQL_EXPORT["asset_peripherals"], engine),
    }
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        for name, df in sheets.items():
            if df.empty:
                df = pd.DataFrame({"info": [f"No rows for {name} at export time."]})
            df.to_excel(xw, sheet_name=name[:31], index=False)
    buf.seek(0)
    return buf.getvalue()


# ── TAB 1: PRODUCTION ─────────────────────────────────────────────────────────
def _render_production_tab(engine, data_lo, data_hi):
    st.subheader("Shop-floor output, yield & machine load")

    depts = _q("SELECT DISTINCT department FROM work_centers ORDER BY 1", engine)["department"].tolist()
    c1, c2 = st.columns([2, 2])
    with c1:
        sel_depts = st.multiselect("Department", depts, default=depts, key="prod_dept") or depts
    with c2:
        rng = st.date_input("Clock-in date range", value=(data_lo, data_hi),
                            min_value=data_lo, max_value=data_hi, key="prod_dates")
    lo, hi = rng if isinstance(rng, (list, tuple)) and len(rng) == 2 else (data_lo, data_hi)
    P = {"depts": list(sel_depts), "lo": lo, "hi": hi}
    _hr()

    # KPI row
    k = _q("""
        SELECT
          COALESCE(SUM(lt.qty_good)  FILTER (WHERE lt.op_code='30'), 0) AS good,
          COALESCE(SUM(lt.qty_scrap) FILTER (WHERE lt.op_code='30'), 0) AS scrap,
          COUNT(DISTINCT lt.machine_id) AS machines,
          CASE WHEN SUM(lt.qty_good)  FILTER (WHERE lt.op_code='30')
                  + SUM(lt.qty_scrap) FILTER (WHERE lt.op_code='30') > 0
               THEN ROUND(100.0 * SUM(lt.qty_good) FILTER (WHERE lt.op_code='30')
                    / (SUM(lt.qty_good)  FILTER (WHERE lt.op_code='30')
                     + SUM(lt.qty_scrap) FILTER (WHERE lt.op_code='30')), 1)
          END AS fpy_pct
        FROM labor_tickets lt
        JOIN work_centers wc ON lt.machine_id = wc.machine_id
        WHERE wc.department = ANY(:depts) AND lt.time_in::date BETWEEN :lo AND :hi
    """, engine, P).iloc[0]
    active = int(_q("SELECT COUNT(DISTINCT machine_id) AS n FROM labor_tickets WHERE time_out IS NULL",
                    engine)["n"].iloc[0])
    good, scrap, machines = int(k["good"]), int(k["scrap"]), int(k["machines"])
    fpy = None if pd.isna(k["fpy_pct"]) else float(k["fpy_pct"])

    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.markdown(_metric_card("Total Parts Produced", f"{good + scrap:,}",
                    footer=f"{good:,} good · {scrap:,} scrap (op 30)"), unsafe_allow_html=True)
    with m2:
        st.markdown(_metric_card("Total Scrap", f"{scrap:,}",
                    value_style=theme.value_gradient("danger") if scrap > 0 else ""),
                    unsafe_allow_html=True)
    with m3:
        fpy_style = "" if fpy is None else theme.value_gradient("success" if fpy >= 98 else "danger")
        st.markdown(_metric_card("First-Pass Yield", _na(fpy, "{:.1f}%"),
                    value_style=fpy_style, footer="Main run op (30)"), unsafe_allow_html=True)
    with m4:
        st.markdown(_metric_card("Active Machines", f"{active}",
                    value_style=theme.value_gradient("primary"),
                    footer=f"clocked in now · {machines} machines logged in range"),
                    unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)

    # Section A — quality & scrap
    a1, a2 = st.columns([1, 1])
    with a1:
        st.subheader("Scrap by machine (op 30)")
        scrap_df = _q("""
            SELECT wc.machine_name AS machine, wc.department AS department,
                   COALESCE(SUM(lt.qty_good), 0)  AS good,
                   COALESCE(SUM(lt.qty_scrap), 0) AS scrap,
                   ROUND(100.0 * SUM(lt.qty_scrap)
                         / NULLIF(SUM(lt.qty_good) + SUM(lt.qty_scrap), 0), 1) AS scrap_pct
            FROM labor_tickets lt
            JOIN work_centers wc ON lt.machine_id = wc.machine_id
            WHERE lt.op_code = '30' AND wc.department = ANY(:depts)
              AND lt.time_in::date BETWEEN :lo AND :hi
            GROUP BY wc.machine_name, wc.department
            HAVING SUM(lt.qty_good) + SUM(lt.qty_scrap) > 0
            ORDER BY scrap DESC
        """, engine, P)
        if scrap_df.empty:
            _empty_state("No scrap in this range",
                         "Every machining (op 30) part passed first-pass inspection for the selected scope.",
                         icon="")
        else:
            scrap_df["scrap"] = pd.to_numeric(scrap_df["scrap"])
            fig = px.bar(scrap_df, x="scrap", y="machine", color="department", orientation="h",
                         color_discrete_map=_DEPT_MAP, height=440,
                         labels={"scrap": "Scrap pieces", "machine": "Machine", "department": "Dept"})
            fig.update_layout(margin=dict(l=120, r=20, t=10, b=10),
                              legend=dict(orientation="h", y=1.05, x=0.5, xanchor="center"),
                              yaxis=dict(autorange="reversed"))
            st.plotly_chart(fig, use_container_width=True)
    with a2:
        st.subheader("First-pass yield by department")
        fpy_df = _q("""
            SELECT wc.department AS department,
                   COALESCE(SUM(lt.qty_good), 0)  AS good,
                   COALESCE(SUM(lt.qty_scrap), 0) AS scrap
            FROM labor_tickets lt
            JOIN work_centers wc ON lt.machine_id = wc.machine_id
            WHERE lt.op_code = '30' AND wc.department = ANY(:depts)
              AND lt.time_in::date BETWEEN :lo AND :hi
            GROUP BY wc.department
            HAVING SUM(lt.qty_good) + SUM(lt.qty_scrap) > 0
        """, engine, P)
        if fpy_df.empty:
            _empty_state("No production yet", "No op-30 parts logged for the selected scope.")
        else:
            fpy_df["good"] = pd.to_numeric(fpy_df["good"])
            fpy_df["scrap"] = pd.to_numeric(fpy_df["scrap"])
            fpy_df["fpy"] = 100 * fpy_df["good"] / (fpy_df["good"] + fpy_df["scrap"])
            fpy_df = fpy_df.sort_values("fpy")
            fig = px.bar(fpy_df, x="fpy", y="department", orientation="h", color="department",
                         color_discrete_map=_DEPT_MAP, height=400,
                         labels={"fpy": "First-pass yield %", "department": "Dept"})
            lo_x = min(90.0, float(fpy_df["fpy"].min()) - 2)
            fig.update_layout(margin=dict(l=80, r=20, t=10, b=10), showlegend=False,
                              xaxis=dict(range=[lo_x, 100]))
            st.plotly_chart(fig, use_container_width=True)
    st.markdown("<br>", unsafe_allow_html=True)

    # Section B — machine load & utilization
    load_df = _q("""
        SELECT wc.machine_name AS machine, wc.department AS department,
               ROUND(COALESCE(SUM(lt.setup_hours), 0)::numeric, 1) AS setup_hrs,
               ROUND(COALESCE(SUM(lt.run_hours), 0)::numeric, 1)   AS run_hrs,
               ROUND(COALESCE(SUM(EXTRACT(EPOCH FROM (lt.time_out - lt.time_in)) / 3600.0)
                              FILTER (WHERE lt.time_out IS NOT NULL), 0)::numeric, 1) AS clocked_span_hrs
        FROM labor_tickets lt
        JOIN work_centers wc ON lt.machine_id = wc.machine_id
        WHERE wc.department = ANY(:depts) AND lt.time_in::date BETWEEN :lo AND :hi
        GROUP BY wc.machine_name, wc.department
        HAVING SUM(COALESCE(lt.setup_hours, 0) + COALESCE(lt.run_hours, 0)) > 0
        ORDER BY SUM(COALESCE(lt.setup_hours, 0) + COALESCE(lt.run_hours, 0)) DESC
    """, engine, P)
    for col in ("setup_hrs", "run_hrs", "clocked_span_hrs"):
        if col in load_df.columns:
            load_df[col] = pd.to_numeric(load_df[col])
    b1, b2 = st.columns([2, 1])
    with b1:
        st.subheader("Logged hours by machine")
        if load_df.empty:
            _empty_state("No logged hours", "No labor was booked in the selected scope.")
        else:
            fig = go.Figure()
            fig.add_trace(go.Bar(y=load_df["machine"], x=load_df["setup_hrs"], name="Setup",
                                 orientation="h", marker_color=theme.PALETTE["border-soft"]))
            fig.add_trace(go.Bar(y=load_df["machine"], x=load_df["run_hrs"], name="Run",
                                 orientation="h", marker_color=theme.PALETTE["primary"]))
            fig.update_layout(barmode="stack", height=440, xaxis_title="Logged hours",
                              margin=dict(l=120, r=20, t=10, b=10),
                              legend=dict(orientation="h", y=1.05, x=0.5, xanchor="center"),
                              yaxis=dict(autorange="reversed"))
            st.plotly_chart(fig, use_container_width=True)
            st.caption("Logged hours = setup + run time booked to each machine in range — a relative load "
                       "indicator (no shift calendar available).")
    with b2:
        st.subheader("Run-hour productivity")
        if load_df.empty:
            _empty_state("Awaiting hours", "Productivity appears once labor is booked.", icon="")
        else:
            run_total = float(load_df["run_hrs"].sum())
            span_total = float(load_df["clocked_span_hrs"].sum())
            prod = 100 * run_total / span_total if span_total else None
            st.markdown(_metric_card("Run-Hour Productivity", _na(prod, "{:.0f}%"),
                        value_style=theme.value_gradient("success") if prod else "",
                        footer="Run time ÷ clocked span (closed tickets)"), unsafe_allow_html=True)
            _insight_card("Utilization basis",
                "Shown as <strong>productive run time</strong> ÷ total <strong>clocked span</strong> over "
                "<strong>closed</strong> tickets only. No fabricated capacity denominator: the dataset has no "
                "shift calendar, so absolute machine utilization cannot be computed without an assumption.",
                accent="var(--info)", margin_top="14px")
    st.markdown("<br>", unsafe_allow_html=True)

    # Section C — department logged-hours mix
    st.subheader("Department logged-hours mix")
    mix_df = _q("""
        SELECT wc.department AS department,
               ROUND(COALESCE(SUM(lt.setup_hours + lt.run_hours), 0)::numeric, 1) AS logged_hours
        FROM labor_tickets lt
        JOIN work_centers wc ON lt.machine_id = wc.machine_id
        WHERE wc.department = ANY(:depts) AND lt.time_in::date BETWEEN :lo AND :hi
        GROUP BY wc.department
        HAVING COALESCE(SUM(lt.setup_hours + lt.run_hours), 0) > 0
        ORDER BY logged_hours DESC
    """, engine, P)
    if mix_df.empty:
        _empty_state("No logged hours", "Nothing booked in the selected scope.")
    else:
        mix_df["logged_hours"] = pd.to_numeric(mix_df["logged_hours"])
        cpie, _crail = st.columns([1, 1])
        with cpie:
            fig = px.pie(mix_df, values="logged_hours", names="department", color="department",
                         color_discrete_map=_DEPT_MAP, hole=0.45, height=320)
            fig.update_layout(margin=dict(l=20, r=20, t=10, b=10),
                              legend=dict(orientation="h", y=-0.1, x=0.5, xanchor="center"))
            st.plotly_chart(fig, use_container_width=True)
    st.markdown("<br>", unsafe_allow_html=True)

    # Section D — labor efficiency (completed jobs; filter-independent)
    st.subheader("Labor efficiency — completed jobs")
    st.caption("Across all completed jobs — spans each job's full life, so it ignores the filters above.")
    eff_df = _q(_SQL_EXPORT["production_jobs"], engine)
    if eff_df.empty:
        _empty_state("No completed jobs", "Labor efficiency appears once jobs reach Completed status.")
    else:
        for col in ("est_hrs", "act_hrs", "var_hrs", "efficiency"):
            eff_df[col] = pd.to_numeric(eff_df[col])
        d1, d2 = st.columns([1, 1])
        with d1:
            bars = eff_df.sort_values("var_hrs")
            colors = [theme.PALETTE["danger"] if v > 0 else theme.PALETTE["success"] for v in bars["var_hrs"]]
            fig = go.Figure(go.Bar(x=bars["var_hrs"], y=bars["job"], orientation="h", marker_color=colors))
            fig.update_layout(height=440, margin=dict(l=70, r=20, t=10, b=10),
                              xaxis_title="Hours vs estimate  (+over / −under)")
            fig.add_vline(x=0, line_width=1, line_color=theme.PALETTE["text-muted"])
            st.plotly_chart(fig, use_container_width=True)
        with d2:
            st.dataframe(eff_df, use_container_width=True, hide_index=True, column_config={
                "job": "Job", "customer": "Customer", "part": "Part",
                "est_hrs": st.column_config.NumberColumn("Est Hrs", format="%.1f"),
                "act_hrs": st.column_config.NumberColumn("Act Hrs", format="%.1f"),
                "var_hrs": st.column_config.NumberColumn("Variance Hrs", format="%+.1f"),
                "efficiency": st.column_config.NumberColumn("Efficiency % (>100 = beat est.)", format="%.1f%%"),
            })

    # Insight — the "so what"
    bits = []
    if fpy is not None:
        bits.append(f"Shop first-pass yield is <strong>{fpy:.1f}%</strong> on {good + scrap:,} op-30 parts.")
    if not scrap_df.empty:
        w = scrap_df.iloc[0]
        wp = w["scrap_pct"]
        if pd.notna(wp) and float(wp) > 5:
            bits.append(f"<strong>{w['machine']}</strong> ({w['department']}) is the scrap hotspot "
                        f"at <strong>{float(wp):.1f}%</strong>.")
    if not eff_df.empty:
        overruns = int((pd.to_numeric(eff_df["var_hrs"]) > 0).sum())
        if overruns:
            bits.append(f"<strong>{overruns} of {len(eff_df)}</strong> completed jobs overran their labor estimate.")
    _insight_card("What to act on", " ".join(bits) or "No production in the selected window.",
                  margin_top="6px")


# ── TAB 2: MAINTENANCE & SERVICE ──────────────────────────────────────────────
def _maint_battery_pm(engine):
    """Forward-looking battery PM cadence (real registry data — useful even before
    any service report exists)."""
    st.subheader("Planned battery replacement cadence")
    st.caption("Forward-looking PM from the asset registry. Service history populates as reports are finalized.")
    bat = _q("""
        SELECT a.display_name AS "Asset", b.description AS "Battery",
               b.part_number AS "PartNumber", b.replacement_interval_days AS "IntervalDays"
        FROM asset_batteries b
        JOIN assets a ON b.asset_id = a.asset_id
        ORDER BY b.replacement_interval_days ASC NULLS LAST, a.display_name
    """, engine)
    if bat.empty:
        _empty_state("No battery records", "No batteries are registered against assets yet.")
    else:
        st.dataframe(bat, use_container_width=True, hide_index=True, column_config={
            "IntervalDays": st.column_config.NumberColumn("Interval (days)", format="%d"),
        })


def _render_maintenance_tab(engine):
    st.subheader("Service events, downtime & parts (finalized records only)")

    gate = _q("""
        SELECT COUNT(*) FILTER (WHERE record_state='Final') AS n_final,
               COUNT(*) FILTER (WHERE record_state='Draft') AS n_draft
        FROM service_reports
    """, engine).iloc[0]
    n_final, n_draft = int(gate["n_final"]), int(gate["n_draft"])

    if n_final == 0:
        _empty_state("No finalized service reports yet",
            "Maintenance analytics activate automatically once reports are finalized "
            "(record_state = Final). Drafts are excluded so KPIs reflect verified work only. "
            f"Drafts in progress: <strong>{n_draft}</strong>. When data arrives this tab shows downtime "
            "totals, a downtime-by-asset Pareto, issue-category and root-cause breakdowns, service-type mix, "
            "parts consumed, and MTBF.", icon="")
        ph = st.columns(4)
        for col, title in zip(ph, ["Finalized Events", "Total Downtime", "Avg Downtime", "Parts Consumed"]):
            with col:
                st.markdown(_metric_card(title, "—"), unsafe_allow_html=True)
        st.markdown("<br>", unsafe_allow_html=True)
        _maint_battery_pm(engine)
        return

    types = ["Preventive", "Corrective", "Emergency"]
    cats = _q("SELECT DISTINCT COALESCE(issue_category,'Unknown') AS c FROM service_reports "
              "WHERE record_state='Final' ORDER BY 1", engine)["c"].tolist()
    c1, c2 = st.columns([2, 2])
    with c1:
        sel_types = st.multiselect("Service type", types, default=types, key="maint_type") or types
    with c2:
        sel_cats = st.multiselect("Issue category", cats, default=cats, key="maint_cat") or cats
    M = {"types": list(sel_types), "cats": list(sel_cats)}
    _hr()

    k = _q("""
        SELECT COUNT(*)                                                          AS events,
               ROUND(COALESCE(SUM(downtime_hours), 0)::numeric, 1)               AS total_dt,
               ROUND(COALESCE(AVG(downtime_hours), 0)::numeric, 1)               AS avg_dt,
               COUNT(*) FILTER (WHERE service_type IN ('Corrective','Emergency')) AS unplanned,
               COUNT(*) FILTER (WHERE service_type='Emergency')                  AS emergency,
               COUNT(DISTINCT asset_id)                                          AS assets_serviced
        FROM service_reports
        WHERE record_state='Final' AND service_type = ANY(:types)
          AND COALESCE(issue_category,'Unknown') = ANY(:cats)
    """, engine, M).iloc[0]
    pk = _q("""
        SELECT COALESCE(SUM(sp.quantity), 0)                              AS parts_qty,
               COALESCE(SUM(sp.quantity) FILTER (WHERE sp.is_battery), 0) AS batt_qty
        FROM service_parts sp
        JOIN service_reports sr ON sp.report_id = sr.report_id
        WHERE sr.record_state='Final' AND sr.service_type = ANY(:types)
          AND COALESCE(sr.issue_category,'Unknown') = ANY(:cats)
    """, engine, M).iloc[0]
    events = int(k["events"])
    total_dt, avg_dt = float(k["total_dt"]), float(k["avg_dt"])
    assets_serviced = int(k["assets_serviced"])
    parts_qty, batt_qty = int(pk["parts_qty"]), int(pk["batt_qty"])

    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.markdown(_metric_card("Finalized Events", f"{events}",
                    value_style=theme.value_gradient("primary"),
                    footer=f"{assets_serviced} assets"), unsafe_allow_html=True)
    with m2:
        st.markdown(_metric_card("Total Downtime (hrs)", f"{total_dt:.1f}",
                    value_style=theme.value_gradient("danger") if total_dt > 0 else ""),
                    unsafe_allow_html=True)
    with m3:
        st.markdown(_metric_card("Avg Downtime / Event", f"{avg_dt:.1f}"), unsafe_allow_html=True)
    with m4:
        st.markdown(_metric_card("Parts Consumed", f"{parts_qty}",
                    footer=f"of which {batt_qty} batteries"), unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)

    # Section A — downtime Pareto by asset
    a1, a2 = st.columns([2, 1])
    dt_df = _q("""
        SELECT COALESCE(a.display_name, sr.asset_code, 'Unknown') AS asset,
               a.equipment_category                              AS category,
               ROUND(COALESCE(SUM(sr.downtime_hours), 0)::numeric, 1) AS downtime_hrs,
               COUNT(*)                                          AS events
        FROM service_reports sr
        LEFT JOIN assets a ON sr.asset_id = a.asset_id
        WHERE sr.record_state='Final' AND sr.service_type = ANY(:types)
          AND COALESCE(sr.issue_category,'Unknown') = ANY(:cats)
        GROUP BY COALESCE(a.display_name, sr.asset_code, 'Unknown'), a.equipment_category
        ORDER BY downtime_hrs DESC
        LIMIT 15
    """, engine, M)
    with a1:
        st.subheader("Downtime by asset")
        if dt_df.empty or pd.to_numeric(dt_df["downtime_hrs"]).sum() == 0:
            _empty_state("No downtime recorded", "Finalized reports in scope logged zero downtime.", icon="")
        else:
            dt_df["downtime_hrs"] = pd.to_numeric(dt_df["downtime_hrs"])
            fig = px.bar(dt_df.sort_values("downtime_hrs"), x="downtime_hrs", y="asset",
                         orientation="h", height=440, color_discrete_sequence=[theme.PALETTE["danger"]],
                         labels={"downtime_hrs": "Downtime hours", "asset": "Asset"})
            fig.update_layout(margin=dict(l=140, r=20, t=10, b=10))
            st.plotly_chart(fig, use_container_width=True)
    with a2:
        st.subheader("Top drivers")
        if not dt_df.empty and pd.to_numeric(dt_df["downtime_hrs"]).sum() > 0:
            total = float(pd.to_numeric(dt_df["downtime_hrs"]).sum())
            top = dt_df.iloc[0]
            _insight_card("Biggest downtime driver",
                          f"<strong>{top['asset']}</strong> accounts for {float(top['downtime_hrs']):.1f} hrs "
                          f"({100 * float(top['downtime_hrs']) / total:.0f}%) of finalized downtime across "
                          f"{int(top['events'])} event(s).", accent="var(--danger)")
            st.dataframe(dt_df[["asset", "events", "downtime_hrs"]], use_container_width=True, hide_index=True,
                         column_config={"asset": "Asset", "events": "Events",
                                        "downtime_hrs": st.column_config.NumberColumn("Downtime (hrs)", format="%.1f")})
    st.markdown("<br>", unsafe_allow_html=True)

    # Section B — issue-category & root-cause Paretos
    b1, b2 = st.columns([1, 1])
    with b1:
        st.subheader("Issue categories")
        iss_df = _q("""
            SELECT COALESCE(issue_category,'Unknown') AS category,
                   COUNT(*) AS events,
                   ROUND(COALESCE(SUM(downtime_hours), 0)::numeric, 1) AS downtime_hrs
            FROM service_reports
            WHERE record_state='Final' AND service_type = ANY(:types)
              AND COALESCE(issue_category,'Unknown') = ANY(:cats)
            GROUP BY COALESCE(issue_category,'Unknown')
            ORDER BY downtime_hrs DESC
        """, engine, M)
        if iss_df.empty:
            _empty_state("No categories to chart", "No finalized events match the current filters.")
        else:
            st.plotly_chart(_pareto_fig(iss_df, "category", "downtime_hrs", "Downtime hrs",
                                        theme.PALETTE["info"]), use_container_width=True)
    with b2:
        st.subheader("Root causes")
        rc_df = _q("""
            SELECT COALESCE(root_cause,'Unknown') AS root_cause,
                   COUNT(*) AS events,
                   ROUND(COALESCE(SUM(downtime_hours), 0)::numeric, 1) AS downtime_hrs
            FROM service_reports
            WHERE record_state='Final' AND service_type = ANY(:types)
              AND COALESCE(issue_category,'Unknown') = ANY(:cats)
            GROUP BY COALESCE(root_cause,'Unknown')
            ORDER BY events DESC
        """, engine, M)
        if rc_df.empty:
            _empty_state("No causes to chart", "No finalized events match the current filters.")
        else:
            st.plotly_chart(_pareto_fig(rc_df, "root_cause", "events", "Events",
                                        theme.PALETTE["dept-lathe"]), use_container_width=True)
    st.markdown("<br>", unsafe_allow_html=True)

    # Section C — service-type mix + MTBF
    c1c, c2c = st.columns([1, 1])
    with c1c:
        st.subheader("Service-type mix")
        mix_df = _q("""
            SELECT service_type AS type, COUNT(*) AS events
            FROM service_reports
            WHERE record_state='Final' AND service_type = ANY(:types)
              AND COALESCE(issue_category,'Unknown') = ANY(:cats)
            GROUP BY service_type
        """, engine, M)
        if mix_df.empty:
            _empty_state("No events", "Nothing to chart for the current filters.")
        else:
            fig = px.pie(mix_df, values="events", names="type", hole=0.45, height=320, color="type",
                         color_discrete_map={"Preventive": theme.PALETTE["success"],
                                             "Corrective": theme.PALETTE["info"],
                                             "Emergency": theme.PALETTE["danger"]})
            fig.update_layout(margin=dict(l=20, r=20, t=10, b=10),
                              legend=dict(orientation="h", y=-0.1, x=0.5, xanchor="center"))
            st.plotly_chart(fig, use_container_width=True)
    with c2c:
        st.subheader("Mean time between failures")
        mt = _q("""
            SELECT COUNT(*) FILTER (WHERE service_type IN ('Corrective','Emergency')) AS unplanned,
                   EXTRACT(EPOCH FROM (MAX(finalized_at) - MIN(finalized_at))) / 86400.0 AS window_days
            FROM service_reports
            WHERE record_state='Final' AND service_type = ANY(:types)
              AND COALESCE(issue_category,'Unknown') = ANY(:cats)
        """, engine, M).iloc[0]
        unplanned = int(mt["unplanned"])
        window_days = None if pd.isna(mt["window_days"]) else float(mt["window_days"])
        if unplanned < 2 or not window_days:
            _empty_state("MTBF not computable",
                         "MTBF needs at least two finalized Corrective/Emergency events spanning time. "
                         "Too few recorded.", icon="")
        else:
            mtbf = window_days / unplanned
            st.markdown(_metric_card("Mean Time Between Failures", f"{mtbf:.1f} days",
                        value_style=theme.value_gradient("success"),
                        footer="Window span ÷ unplanned events"), unsafe_allow_html=True)
            _insight_card("MTBF basis",
                          "Calendar days between unplanned (Corrective/Emergency) finalized events. No machine "
                          "run-clock exists, so calendar span is the defensible denominator.", accent="var(--info)")
    st.markdown("<br>", unsafe_allow_html=True)

    # Finalized service log
    st.subheader("Finalized service log")
    log_df = _q("""
        SELECT service_id AS "ServiceID", asset_code AS "Asset", service_type AS "Type",
               issue_category AS "Issue", root_cause AS "RootCause",
               downtime_hours AS "DowntimeHrs", return_to_service AS "Returned",
               verified_by AS "VerifiedBy", TO_CHAR(finalized_at,'YYYY-MM-DD') AS "Finalized"
        FROM service_reports
        WHERE record_state='Final' AND service_type = ANY(:types)
          AND COALESCE(issue_category,'Unknown') = ANY(:cats)
        ORDER BY finalized_at DESC NULLS LAST
    """, engine, M)
    if log_df.empty:
        _empty_state("No finalized reports match", "Widen the filters above to see service history.")
    else:
        st.dataframe(log_df, use_container_width=True, hide_index=True, column_config={
            "DowntimeHrs": st.column_config.NumberColumn("Downtime (hrs)", format="%.1f")})

    st.markdown("<br>", unsafe_allow_html=True)
    _maint_battery_pm(engine)


# ── TAB 3: ASSET REGISTRY ─────────────────────────────────────────────────────
def _render_asset_tab(engine):
    st.subheader("Fleet composition, age & data quality")

    cats = _q("SELECT DISTINCT equipment_category FROM assets WHERE equipment_category IS NOT NULL ORDER BY 1",
              engine)["equipment_category"].tolist()
    yb = _q("SELECT MIN(build_year) AS lo, MAX(build_year) AS hi FROM assets", engine).iloc[0]
    if pd.isna(yb["lo"]):
        y_lo, y_hi = 1990, date.today().year
    else:
        y_lo, y_hi = int(yb["lo"]), int(yb["hi"])
    if y_lo >= y_hi:
        y_lo = y_hi - 1
    c1, c2, c3 = st.columns([2, 2, 2])
    with c1:
        sel_cats = st.multiselect("Equipment category", cats, default=cats, key="asset_cat") or cats
    with c2:
        y0, y1 = st.slider("Build year", y_lo, y_hi, (y_lo, y_hi), key="asset_years")
    with c3:
        incl_null = st.checkbox("Include unknown build year", value=True, key="asset_incl_null")
    A = {"cats": list(sel_cats), "y0": y0, "y1": y1, "incl_null": incl_null}
    _hr()

    k = _q("""
        SELECT COUNT(*)                                                      AS total,
               COUNT(*) FILTER (WHERE build_year IS NULL)                    AS missing_year,
               COUNT(*) FILTER (WHERE asset_status IS NULL)                  AS missing_status,
               COUNT(*) FILTER (WHERE planned_pm_interval_days IS NULL)      AS missing_pm,
               ROUND(AVG(EXTRACT(YEAR FROM CURRENT_DATE) - build_year)
                     FILTER (WHERE build_year IS NOT NULL), 1)               AS avg_age
        FROM assets
        WHERE equipment_category = ANY(:cats)
          AND ((build_year BETWEEN :y0 AND :y1) OR (:incl_null AND build_year IS NULL))
    """, engine, A).iloc[0]
    total = int(k["total"]); missing_year = int(k["missing_year"])
    missing_pm = int(k["missing_pm"])
    avg_age = None if pd.isna(k["avg_age"]) else float(k["avg_age"])

    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.markdown(_metric_card("Assets in Fleet", f"{total}",
                    value_style=theme.value_gradient("primary")), unsafe_allow_html=True)
    with m2:
        age_style = theme.value_gradient("danger") if (avg_age is not None and avg_age > 20) else ""
        st.markdown(_metric_card("Avg Equipment Age", _na(avg_age, "{:.0f} yrs"),
                    value_style=age_style, footer="CURRENT_DATE − build_year"), unsafe_allow_html=True)
    with m3:
        st.markdown(_metric_card("Missing Build Year", f"{missing_year}",
                    value_style=theme.value_gradient("danger") if missing_year > 0 else "",
                    footer=f"{missing_year}/{total} assets"), unsafe_allow_html=True)
    with m4:
        st.markdown(_metric_card("PM Interval Not Set", f"{missing_pm}",
                    value_style=theme.value_gradient("danger") if missing_pm > 0 else "",
                    footer="can't compute overdue PM"), unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)

    # Section A — fleet composition
    s1, s2 = st.columns([1, 1])
    with s1:
        st.subheader("By equipment category")
        cat_df = _q("""
            SELECT equipment_category AS category, COUNT(*) AS count
            FROM assets
            WHERE equipment_category = ANY(:cats)
              AND ((build_year BETWEEN :y0 AND :y1) OR (:incl_null AND build_year IS NULL))
            GROUP BY equipment_category ORDER BY count DESC
        """, engine, A)
        if cat_df.empty:
            _empty_state("No assets match filters", "Widen the category or build-year range.")
        else:
            fig = px.pie(cat_df, values="count", names="category", color="category",
                         color_discrete_map=theme.DEPARTMENT_COLORS, hole=0.45, height=400)
            fig.update_layout(margin=dict(l=20, r=20, t=10, b=10),
                              legend=dict(orientation="h", y=-0.1, x=0.5, xanchor="center"))
            st.plotly_chart(fig, use_container_width=True)
    with s2:
        st.subheader("By department")
        dep_df = _q("""
            SELECT CASE department_code WHEN 'L' THEN 'Lathe' WHEN 'M' THEN 'Mill'
                     WHEN 'S' THEN 'Swiss' ELSE COALESCE(department_code,'Unknown') END AS department,
                   COUNT(*) AS count
            FROM assets
            WHERE equipment_category = ANY(:cats)
              AND ((build_year BETWEEN :y0 AND :y1) OR (:incl_null AND build_year IS NULL))
            GROUP BY 1 ORDER BY count DESC
        """, engine, A)
        if dep_df.empty:
            _empty_state("No assets match filters", "Widen the category or build-year range.")
        else:
            fig = px.bar(dep_df, x="department", y="count", color="department",
                         color_discrete_map=theme.DEPARTMENT_COLORS, height=400,
                         labels={"department": "Department", "count": "Assets"})
            fig.update_layout(margin=dict(l=40, r=20, t=10, b=10), showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
    st.markdown("<br>", unsafe_allow_html=True)

    # Section B — equipment age distribution
    e1, e2 = st.columns([2, 1])
    age_df = _q("""
        SELECT CASE
                 WHEN build_year IS NULL THEN 'Unknown'
                 WHEN EXTRACT(YEAR FROM CURRENT_DATE) - build_year < 5  THEN '0-4 yrs'
                 WHEN EXTRACT(YEAR FROM CURRENT_DATE) - build_year < 10 THEN '5-9 yrs'
                 WHEN EXTRACT(YEAR FROM CURRENT_DATE) - build_year < 20 THEN '10-19 yrs'
                 ELSE '20+ yrs'
               END AS age_band,
               COUNT(*) AS count
        FROM assets
        WHERE equipment_category = ANY(:cats)
          AND ((build_year BETWEEN :y0 AND :y1) OR (:incl_null AND build_year IS NULL))
        GROUP BY 1
    """, engine, A)
    with e1:
        st.subheader("Equipment age distribution")
        order = ["0-4 yrs", "5-9 yrs", "10-19 yrs", "20+ yrs", "Unknown"]
        age_df = age_df.set_index("age_band").reindex(order, fill_value=0).reset_index()
        age_df.columns = ["age_band", "count"]
        bar_colors = []
        for band in age_df["age_band"]:
            if band == "20+ yrs":
                bar_colors.append(theme.PALETTE["danger"])
            elif band == "Unknown":
                bar_colors.append(theme.PALETTE["border-soft"])
            else:
                bar_colors.append(theme.PALETTE["info"])
        fig = go.Figure(go.Bar(x=age_df["age_band"], y=age_df["count"], marker_color=bar_colors))
        fig.update_layout(height=400, margin=dict(l=40, r=20, t=10, b=10),
                          xaxis_title="Age band", yaxis_title="Assets")
        st.plotly_chart(fig, use_container_width=True)
    with e2:
        st.subheader("Age insight")
        n_old = int(age_df.loc[age_df["age_band"] == "20+ yrs", "count"].iloc[0])
        n_unknown = int(age_df.loc[age_df["age_band"] == "Unknown", "count"].iloc[0])
        _insight_card("Fleet age",
                      f"<strong>{n_old}</strong> asset(s) are 20+ yrs old (flag for capital-replacement review); "
                      f"<strong>{n_unknown}</strong> lack a build year and can't be aged.",
                      accent="var(--dept-lathe)")
    st.markdown("<br>", unsafe_allow_html=True)

    # Section C — battery & peripheral inventory
    i1, i2 = st.columns([1, 1])
    with i1:
        st.subheader("Battery replacement cadence")
        bat_df = _q("""
            SELECT b.replacement_interval_days AS interval_days, COUNT(*) AS batteries,
                   COUNT(DISTINCT b.asset_id) AS assets
            FROM asset_batteries b
            JOIN assets a ON b.asset_id = a.asset_id
            WHERE a.equipment_category = ANY(:cats)
            GROUP BY b.replacement_interval_days ORDER BY b.replacement_interval_days
        """, engine, A)
        if bat_df.empty:
            _empty_state("No batteries", "No batteries registered for the selected categories.")
        else:
            bat_df["interval_days"] = bat_df["interval_days"].astype(str)
            fig = px.bar(bat_df, x="interval_days", y="batteries", height=360,
                         color_discrete_sequence=[theme.PALETTE["success"]],
                         labels={"interval_days": "Replacement interval (days)", "batteries": "Batteries"})
            fig.update_layout(margin=dict(l=40, r=20, t=10, b=10))
            st.plotly_chart(fig, use_container_width=True)
            st.caption("Battery replacement cadence — drives spares planning.")
    with i2:
        st.subheader("Peripheral inventory")
        per_df = _q("""
            SELECT pe.name AS "Equipment", COALESCE(pe.make,'Unknown') AS "Make",
                   COUNT(*) AS "Units", COUNT(DISTINCT pe.asset_id) AS "OnAssets"
            FROM asset_peripheral_equipment pe
            JOIN assets a ON pe.asset_id = a.asset_id
            WHERE a.equipment_category = ANY(:cats)
            GROUP BY pe.name, COALESCE(pe.make,'Unknown') ORDER BY "Units" DESC
        """, engine, A)
        if per_df.empty:
            _empty_state("No peripherals", "No peripheral equipment for the selected categories.")
        else:
            st.dataframe(per_df, use_container_width=True, hide_index=True)
    st.markdown("<br>", unsafe_allow_html=True)

    # Section D — registry data quality (centerpiece)
    st.subheader("Registry data quality")
    _insight_card("Preventive-maintenance intervals not configured",
                  f"<strong>{missing_pm} of {total}</strong> in-scope assets have no planned PM interval, and "
                  "commission dates & asset status are also unpopulated. Overdue-PM tracking activates "
                  "automatically once intervals and commission/last-service dates are entered.",
                  accent="var(--danger)")
    flag_df = _q("""
        SELECT a.display_name AS "Asset", a.equipment_category AS "Category",
               CASE WHEN a.build_year IS NULL THEN '' ELSE '✓' END AS "BuildYear",
               CASE WHEN a.asset_status IS NULL THEN '' ELSE '✓' END AS "Status",
               CASE WHEN a.planned_pm_interval_days IS NULL THEN '' ELSE '✓' END AS "PMInterval",
               CASE WHEN a.commission_date IS NULL THEN '' ELSE '✓' END AS "Commissioned"
        FROM assets a
        WHERE a.equipment_category = ANY(:cats)
          AND ((a.build_year BETWEEN :y0 AND :y1) OR (:incl_null AND a.build_year IS NULL))
        ORDER BY (a.build_year IS NULL) DESC, a.display_name
    """, engine, A)
    if flag_df.empty:
        _empty_state("No assets match filters", "Widen the category or build-year range.")
    else:
        st.dataframe(flag_df, use_container_width=True, hide_index=True)


# ── TAB 4: EXPORT ─────────────────────────────────────────────────────────────
def _render_export_tab(engine):
    st.subheader("Download reports")
    st.caption("CSV files mirror the tables shown in each tab (full datasets). The workbook bundles every "
               "view as a multi-sheet .xlsx.")
    _hr()

    n_final = int(_q("SELECT COUNT(*) AS n FROM service_reports WHERE record_state='Final'",
                     engine)["n"].iloc[0])
    left, right = st.columns([1, 1])
    with left:
        st.markdown("**Individual views (CSV)**")
        csv_buttons = [
            ("Production — Job Efficiency",        "production_jobs",         "production_jobs.csv"),
            ("Production — Scrap by Machine",      "production_scrap",        "production_scrap.csv"),
            ("Production — Logged Hours",          "production_machine_load", "production_machine_load.csv"),
            ("Maintenance — Finalized Reports",   "service_reports_final",   "service_reports_final.csv"),
            ("Maintenance — Service Parts",       "service_parts",           "service_parts.csv"),
            ("Asset Registry",                    "assets",                  "assets.csv"),
            ("Asset Batteries",                   "asset_batteries",         "asset_batteries.csv"),
            ("Asset Peripherals",                 "asset_peripherals",       "asset_peripherals.csv"),
        ]
        for label, key, fname in csv_buttons:
            df = _q(_SQL_EXPORT[key], engine)
            st.download_button(label, data=df.to_csv(index=False).encode("utf-8"),
                               file_name=fname, mime="text/csv",
                               use_container_width=True, key=f"csv_{key}")
        if n_final == 0:
            st.caption("Maintenance exports are header-only until reports are finalized.")
    with right:
        st.markdown("**Full report (Excel)**")
        xlsx_bytes = _build_full_report(engine)
        st.download_button("Download Full Report (.xlsx)", data=xlsx_bytes,
            file_name=f"maintdb_report_{date.today():%Y%m%d}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True, key="dl_full_xlsx")
        _insight_card("Workbook contents",
            "9 sheets: Summary, Production_Jobs, Scrap_By_Machine, Machine_Logged_Hrs, Service_Reports, "
            "Service_Parts, Assets, Asset_Batteries, Asset_Peripherals. Maintenance sheets carry finalized "
            "reports only and are header-only until reports are finalized.", accent="var(--primary)",
            margin_top="14px")


def render_reporting_suite_page():
    st.markdown('<div class="gradient-header">Reporting &amp; Analytics Suite</div>', unsafe_allow_html=True)

    engine = _require_db()
    if engine is None:
        return

    # Production data window, derived once (never hardcoded) and shared with Tab 1.
    win = _q("SELECT MIN(time_in)::date AS lo, MAX(time_in)::date AS hi FROM labor_tickets", engine)
    if win.empty or pd.isna(win["lo"].iloc[0]):
        data_lo = data_hi = date.today()
    else:
        data_lo = pd.to_datetime(win["lo"].iloc[0]).date()
        data_hi = pd.to_datetime(win["hi"].iloc[0]).date()
    st.caption(f"Production data window: {data_lo} → {data_hi} · Today: {date.today()}")

    tab_prod, tab_maint, tab_asset, tab_export = st.tabs([
        "Production",
        "Maintenance & Service",
        "Asset Registry",
        "Export",
    ])
    with tab_prod:
        _render_production_tab(engine, data_lo, data_hi)
    with tab_maint:
        _render_maintenance_tab(engine)
    with tab_asset:
        _render_asset_tab(engine)
    with tab_export:
        _render_export_tab(engine)

# -----------------------------------------------------------------------------
# PAGE: EDIT ASSET
# -----------------------------------------------------------------------------
def render_edit_asset_page():
    engine = _require_db()
    if engine is None:
        return
    asset_id = st.session_state.get("edit_asset_id")
    if not asset_id:
        _set_page("View Assets")
        st.rerun()

    df = pd.read_sql_query(
        text("SELECT * FROM assets WHERE asset_id = :id"), engine, params={"id": asset_id}
    )
    if df.empty:
        st.error(f"Asset {asset_id} not found.")
        return
    a = df.iloc[0]

    bat_df = pd.read_sql_query(
        text("SELECT * FROM asset_batteries WHERE asset_id = :id ORDER BY battery_number"),
        engine, params={"id": asset_id}
    )
    eq_df = pd.read_sql_query(
        text("SELECT * FROM asset_peripheral_equipment WHERE asset_id = :id ORDER BY equip_number"),
        engine, params={"id": asset_id}
    )

    st.markdown(f'<div class="gradient-header">Edit — {a["display_name"] or asset_id}</div>', unsafe_allow_html=True)

    col_back, col_del = st.columns([5, 1])
    with col_back:
        if st.button("← Back to Registry"):
            st.session_state.pop("edit_asset_id", None)
            st.session_state.pop("confirm_delete_asset", None)
            _set_page("View Assets")
            st.rerun()
    with col_del:
        if st.button("Delete Asset"):
            st.session_state.confirm_delete_asset = asset_id

    if st.session_state.get("confirm_delete_asset") == asset_id:
        st.error(f"Permanently delete **{asset_id}**? This cannot be undone.")
        c1, c2 = st.columns(2)
        with c1:
            if st.button("Yes, Delete Permanently", key="confirm_del_asset"):
                with engine.connect() as conn:
                    conn.execute(text("DELETE FROM asset_peripheral_equipment WHERE asset_id = :id"), {"id": asset_id})
                    conn.execute(text("DELETE FROM asset_batteries WHERE asset_id = :id"), {"id": asset_id})
                    conn.execute(text("DELETE FROM assets WHERE asset_id = :id"), {"id": asset_id})
                    conn.commit()
                st.session_state.pop("confirm_delete_asset", None)
                st.session_state.pop("edit_asset_id", None)
                _set_page("View Assets")
                st.rerun()
        with c2:
            if st.button("Cancel", key="cancel_del_asset"):
                st.session_state.pop("confirm_delete_asset", None)
                st.rerun()
        return

    st.markdown("---")

    CATEGORIES   = ["Lathe", "Mill", "Swiss", "QC", "Support", "Other"]
    STATUS_OPTS  = ["Active", "Inactive", "Under Repair", "Decommissioned"]

    with st.form("edit_asset_form"):

        st.subheader("Identity & Classification")
        c1, c2 = st.columns(2)
        with c1:
            st.text_input("Asset ID", value=asset_id, disabled=True)
            cat_idx = CATEGORIES.index(a["equipment_category"]) if a["equipment_category"] in CATEGORIES else 5
            equipment_category = st.selectbox("Equipment Category", CATEGORIES, index=cat_idx)
            primary_function   = st.text_input("Primary Function", value=a["primary_function"] or "")
            stat_idx = STATUS_OPTS.index(a["asset_status"]) if a["asset_status"] in STATUS_OPTS else 0
            asset_status = st.selectbox("Asset Status", STATUS_OPTS, index=stat_idx)
        with c2:
            display_name  = st.text_input("Display Name", value=a["display_name"] or "")
            facility      = st.text_input("Facility", value=a["facility"] or "")
            area_cell     = st.text_input("Area / Cell", value=a["area_cell"] or "")
            commission_date = st.date_input("Commission Date", value=a["commission_date"] or None)
            planned_pm    = st.number_input("Planned PM Interval (Days)",
                                            value=int(a["planned_pm_interval_days"]) if a["planned_pm_interval_days"] else 0,
                                            min_value=0, step=30)

        st.markdown("---")
        st.subheader("Technical Specifications")
        c3, c4 = st.columns(2)
        with c3:
            manufacturer  = st.text_input("Manufacturer",   value=a["manufacturer"]  or "")
            model         = st.text_input("Model",          value=a["model"]          or "")
            serial_number = st.text_input("Serial Number",  value=a["serial_number"] or "")
        with c4:
            control_type  = st.text_input("Control Type",   value=a["control_type"]  or "")
            build_year    = st.number_input("Build Year", min_value=1900, max_value=2100,
                                            value=int(a["build_year"]) if a["build_year"] else None, step=1, format="%d")

        st.markdown("---")
        st.subheader("Distributor & Contacts")
        c5, c6 = st.columns(2)
        with c5:
            distributor       = st.text_input("Distributor",       value=a["distributor"]       or "")
            distributor_email = st.text_input("Distributor Email", value=a["distributor_email"] or "")
            distributor_phone = st.text_input("Distributor Phone", value=a["distributor_phone"] or "")
        with c6:
            vendor_contacts = st.text_area("Vendor Contacts", value=a["vendor_contacts"] or "")

        st.markdown("---")
        st.subheader("Notes & Documentation")
        installation_notes = st.text_area("Installation Notes", value=a["installation_notes"] or "")
        known_quirks       = st.text_area("Known Quirks",       value=a["known_quirks"]       or "")
        c7, c8 = st.columns(2)
        with c7:
            special_tooling   = st.text_input("Special Tooling",   value=a["special_tooling"]   or "")
        with c8:
            reference_document = st.text_input("Reference Document", value=a["reference_document"] or "")

        st.markdown("---")
        st.subheader("Battery Configuration")
        bat_rows = bat_df.set_index("battery_number").to_dict("index") if not bat_df.empty else {}
        bat_cols = st.columns(3)
        battery_data = []
        for n in range(1, 4):
            b = bat_rows.get(n, {})
            with bat_cols[n - 1]:
                st.markdown(f"**Battery {n}**")
                bd = st.text_input("Description", value=b.get("description") or "", key=f"bat{n}d")
                bp = st.text_input("Part Number",  value=b.get("part_number") or "",  key=f"bat{n}p")
                bi = st.number_input("Interval (Days)", value=int(b.get("replacement_interval_days") or 0),
                                     min_value=0, step=30, key=f"bat{n}i")
            battery_data.append((n, bd, bp, bi))

        st.markdown("---")
        st.subheader("Peripheral Equipment")
        eq_rows = eq_df.set_index("equip_number").to_dict("index") if not eq_df.empty else {}
        eq_cols = st.columns(3)
        equipment_data = []
        for n in range(1, 4):
            e = eq_rows.get(n, {})
            with eq_cols[n - 1]:
                st.markdown(f"**Equipment {n}**")
                en   = st.text_input("Name",   value=e.get("name")          or "", key=f"eq{n}n")
                em   = st.text_input("Make",   value=e.get("make")          or "", key=f"eq{n}m")
                emdl = st.text_input("Model",  value=e.get("model")         or "", key=f"eq{n}mdl")
                es   = st.text_input("Serial", value=e.get("serial_number") or "", key=f"eq{n}s")
            equipment_data.append((n, en, em, emdl, es))

        saved = st.form_submit_button("Save All Changes", use_container_width=True)

    if saved:
        try:
            with engine.connect() as conn:
                conn.execute(text("""
                    UPDATE assets SET
                        display_name             = :display_name,
                        short_name               = :display_name,
                        equipment_category       = :category,
                        primary_function         = :primary_function,
                        asset_status             = :asset_status,
                        facility                 = :facility,
                        area_cell                = :area_cell,
                        commission_date          = :commission_date,
                        planned_pm_interval_days = :pm_interval,
                        manufacturer             = :manufacturer,
                        model                    = :model,
                        serial_number            = :serial_number,
                        control_type             = :control_type,
                        build_year               = :build_year,
                        distributor              = :distributor,
                        distributor_email        = :distributor_email,
                        distributor_phone        = :distributor_phone,
                        vendor_contacts          = :vendor_contacts,
                        installation_notes       = :installation_notes,
                        known_quirks             = :known_quirks,
                        special_tooling          = :special_tooling,
                        reference_document       = :reference_document
                    WHERE asset_id = :asset_id
                """), {
                    "asset_id":          asset_id,
                    "display_name":      display_name.strip() or None,
                    "category":          equipment_category,
                    "primary_function":  primary_function.strip() or None,
                    "asset_status":      asset_status,
                    "facility":          facility.strip() or None,
                    "area_cell":         area_cell.strip() or None,
                    "commission_date":   commission_date,
                    "pm_interval":       planned_pm or None,
                    "manufacturer":      manufacturer.strip() or None,
                    "model":             model.strip() or None,
                    "serial_number":     serial_number.strip() or None,
                    "control_type":      control_type.strip() or None,
                    "build_year":        int(build_year) if build_year is not None else None,
                    "distributor":       distributor.strip() or None,
                    "distributor_email": distributor_email.strip() or None,
                    "distributor_phone": distributor_phone.strip() or None,
                    "vendor_contacts":   vendor_contacts.strip() or None,
                    "installation_notes": installation_notes.strip() or None,
                    "known_quirks":      known_quirks.strip() or None,
                    "special_tooling":   special_tooling.strip() or None,
                    "reference_document": reference_document.strip() or None,
                })

                conn.execute(text("DELETE FROM asset_batteries WHERE asset_id = :id"), {"id": asset_id})
                for n, desc, part, interval in battery_data:
                    if desc or part:
                        conn.execute(text("""
                            INSERT INTO asset_batteries (asset_id, battery_number, description, part_number, replacement_interval_days)
                            VALUES (:id, :n, :desc, :part, :interval)
                        """), {"id": asset_id, "n": n, "desc": desc or None,
                               "part": part or None, "interval": interval})

                conn.execute(text("DELETE FROM asset_peripheral_equipment WHERE asset_id = :id"), {"id": asset_id})
                for n, name, make, mdl, serial in equipment_data:
                    if name:
                        conn.execute(text("""
                            INSERT INTO asset_peripheral_equipment (asset_id, equip_number, name, make, model, serial_number)
                            VALUES (:id, :n, :name, :make, :model, :serial)
                        """), {"id": asset_id, "n": n, "name": name,
                               "make": make or None, "model": mdl or None, "serial": serial or None})

                conn.commit()
            st.success(f"{asset_id} updated successfully!")
        except Exception as e:
            st.error(f"Error saving: {e}")


# -----------------------------------------------------------------------------
# PAGE: RECORDS MANAGER  (CRUD for ERP tables)
# -----------------------------------------------------------------------------
def _clean(val):
    if val is None:
        return None
    try:
        if pd.isna(val):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(val, str) and not val.strip():
        return None
    return val


def _save_crud(engine, original, edited, table, pk, pk_is_serial=False):
    with engine.connect() as conn:
        if pk_is_serial:
            existing = edited[edited[pk].notna()].copy()
            new_rows = edited[edited[pk].isna()].copy()
            orig_pks = set(original[pk].tolist())
            edit_pks = set(existing[pk].tolist())
        else:
            orig_pks = set(original[pk].tolist())
            edit_pks = set(edited[pk].tolist()) if not edited.empty else set()
            existing = edited[edited[pk].isin(orig_pks)]
            new_rows = edited[~edited[pk].isin(orig_pks)]
            # Ignore blank rows the data_editor's ＋ button leaves behind when the
            # PK column is locked — real inserts go through the dedicated Add form.
            new_rows = new_rows[
                new_rows[pk].notna() & (new_rows[pk].astype(str).str.strip() != "")
            ]

        # Deletes
        for pk_val in orig_pks - edit_pks:
            conn.execute(
                text(f"DELETE FROM {table} WHERE {pk} = :pk"),
                {"pk": int(pk_val) if pk_is_serial else pk_val}
            )

        # Updates
        non_pk_cols = [c for c in original.columns if c != pk]
        for _, row in existing.iterrows():
            orig_row = original[original[pk] == row[pk]]
            if orig_row.empty:
                continue
            params = {c: _clean(row[c]) for c in non_pk_cols}
            params[pk] = int(row[pk]) if pk_is_serial else row[pk]
            set_clause = ", ".join(f"{c} = :{c}" for c in non_pk_cols)
            conn.execute(text(f"UPDATE {table} SET {set_clause} WHERE {pk} = :{pk}"), params)

        # Inserts
        insert_cols = [c for c in edited.columns if not (pk_is_serial and c == pk)]
        for _, row in new_rows.iterrows():
            params = {c: _clean(row[c]) for c in insert_cols}
            col_list = ", ".join(insert_cols)
            val_list = ", ".join(f":{c}" for c in insert_cols)
            conn.execute(text(f"INSERT INTO {table} ({col_list}) VALUES ({val_list})"), params)

        conn.commit()


_CRUD_DEFAULT_CAPTION = "Add rows with the ＋ button. Click a cell to edit. Save when done."
_CRUD_LOCKED_CAPTION = (
    "IDs are locked once a record exists — edit the other fields in place and Save. "
    "Use the form below to add a record, or a row's to remove one."
)


def _friendly_db_error(e):
    """Turn a raw database error into a plain-language message, or None if unknown."""
    msg = str(getattr(e, "orig", e)).lower()
    if "foreign key" in msg:
        return ("This record is still used by other records (e.g. labor tickets). "
                "Reassign or remove those first, then try again.")
    if "duplicate key" in msg or "unique constraint" in msg:
        return "That ID already exists — pick a different one."
    return None


def _render_add_form(engine, key, table, add_fields):
    """Dedicated insert form for tables whose primary key is locked in the editor.
    add_fields: list of (column, label, kind, options) where kind is text/number/date/select.
    The first field is treated as the required primary key."""
    with st.expander("Add a new record"):
        with st.form(f"add_{key}", clear_on_submit=True):
            vals = {}
            for col, label, kind, options in add_fields:
                wkey = f"add_{key}_{col}"
                if kind == "select":
                    vals[col] = st.selectbox(label, options, key=wkey)
                elif kind == "number":
                    vals[col] = st.number_input(label, value=None, step=1.0, key=wkey)
                elif kind == "date":
                    vals[col] = st.date_input(label, value=None, key=wkey)
                else:
                    vals[col] = st.text_input(label, key=wkey)
            if st.form_submit_button("Add"):
                pk_col, pk_label = add_fields[0][0], add_fields[0][1]
                if not str(vals.get(pk_col) or "").strip():
                    st.warning(f"{pk_label} is required.")
                    return
                params = {c: _clean(v) for c, v in vals.items()}
                cols = ", ".join(vals.keys())
                ph = ", ".join(f":{c}" for c in vals.keys())
                try:
                    with engine.connect() as conn:
                        conn.execute(text(f"INSERT INTO {table} ({cols}) VALUES ({ph})"), params)
                        conn.commit()
                    st.session_state.pop(f"records_{key}", None)
                    st.success("Added.")
                    st.rerun()
                except Exception as e:
                    st.error(_friendly_db_error(e) or f"Error: {e}")


def _crud_tab(engine, key, query, table, pk, column_config, pk_is_serial=False,
              caption=_CRUD_DEFAULT_CAPTION, add_fields=None):
    st.caption(caption)
    state_key = f"records_{key}"
    if state_key not in st.session_state:
        st.session_state[state_key] = pd.read_sql_query(query, engine)

    edited = st.data_editor(
        st.session_state[state_key],
        num_rows="dynamic",
        use_container_width=True,
        column_config=column_config,
        key=f"editor_{key}",
        hide_index=True,
    )

    c1, c2, _ = st.columns([1, 1, 4])
    with c1:
        if st.button("Save", key=f"save_{key}", use_container_width=True):
            try:
                _save_crud(engine, st.session_state[state_key], edited, table, pk, pk_is_serial)
                del st.session_state[state_key]
                st.success("Saved.")
                st.rerun()
            except Exception as e:
                st.error(_friendly_db_error(e) or f"Error: {e}")
    with c2:
        if st.button("Discard", key=f"discard_{key}", use_container_width=True):
            del st.session_state[state_key]
            st.rerun()

    if add_fields:
        _render_add_form(engine, key, table, add_fields)


def render_records_manager_page():
    st.markdown('<div class="gradient-header">Records Manager</div>', unsafe_allow_html=True)
    engine = _require_db()
    if engine is None:
        return

    tab_wc, tab_emp, tab_jobs, tab_lt = st.tabs([
        "Work Centers", "Employees", "Jobs", "Labor Tickets"
    ])

    with tab_wc:
        _crud_tab(
            engine, "wc",
            query="SELECT machine_id, machine_name, department FROM work_centers ORDER BY machine_id",
            table="work_centers", pk="machine_id",
            caption=_CRUD_LOCKED_CAPTION,
            column_config={
                "machine_id":   st.column_config.TextColumn("Machine ID", disabled=True),
                "machine_name": st.column_config.TextColumn("Machine Name", required=True),
                "department":   st.column_config.SelectboxColumn(
                    "Department", options=["Lathe", "Mill", "Swiss", "QC", "Support"], required=True
                ),
            },
            add_fields=[
                ("machine_id",   "Machine ID",   "text",   None),
                ("machine_name", "Machine Name", "text",   None),
                ("department",   "Department",   "select", ["Lathe", "Mill", "Swiss", "QC", "Support"]),
            ],
        )

    with tab_emp:
        _crud_tab(
            engine, "emp",
            query="SELECT employee_id, name, role FROM employees ORDER BY employee_id",
            table="employees", pk="employee_id",
            caption=_CRUD_LOCKED_CAPTION,
            column_config={
                "employee_id": st.column_config.TextColumn("Employee ID", disabled=True),
                "name":        st.column_config.TextColumn("Name", required=True),
                "role":        st.column_config.TextColumn("Role"),
            },
            add_fields=[
                ("employee_id", "Employee ID", "text", None),
                ("name",        "Name",        "text", None),
                ("role",        "Role",        "text", None),
            ],
        )

    with tab_jobs:
        _crud_tab(
            engine, "jobs",
            query="""
                SELECT job_no, part_no, customer, order_qty, due_date,
                       est_setup_hours, est_run_hours, status
                FROM jobs ORDER BY job_no
            """,
            table="jobs", pk="job_no",
            caption=_CRUD_LOCKED_CAPTION,
            column_config={
                "job_no":          st.column_config.TextColumn("Job #", disabled=True),
                "part_no":         st.column_config.TextColumn("Part No"),
                "customer":        st.column_config.TextColumn("Customer"),
                "order_qty":       st.column_config.NumberColumn("Order Qty", min_value=0, step=1),
                "due_date":        st.column_config.DateColumn("Due Date"),
                "est_setup_hours": st.column_config.NumberColumn("Est Setup Hrs", format="%.2f"),
                "est_run_hours":   st.column_config.NumberColumn("Est Run Hrs",   format="%.2f"),
                "status":          st.column_config.SelectboxColumn(
                    "Status", options=["Active", "Scheduled", "Completed", "On Hold"]
                ),
            },
            add_fields=[
                ("job_no",          "Job #",         "text",   None),
                ("part_no",         "Part No",       "text",   None),
                ("customer",        "Customer",      "text",   None),
                ("order_qty",       "Order Qty",     "number", None),
                ("due_date",        "Due Date",      "date",   None),
                ("est_setup_hours", "Est Setup Hrs", "number", None),
                ("est_run_hours",   "Est Run Hrs",   "number", None),
                ("status",          "Status",        "select", ["Active", "Scheduled", "Completed", "On Hold"]),
            ],
        )

    with tab_lt:
        _crud_tab(
            engine, "lt",
            caption="Ticket ID is auto-assigned on new rows. Add rows with the ＋ button.",
            query="""
                SELECT ticket_id, employee_id, job_no, machine_id, op_code, op_desc,
                       time_in, time_out, setup_hours, run_hours, qty_good, qty_scrap
                FROM labor_tickets ORDER BY ticket_id
            """,
            table="labor_tickets", pk="ticket_id", pk_is_serial=True,
            column_config={
                "ticket_id":   st.column_config.NumberColumn("Ticket ID", disabled=True),
                "employee_id": st.column_config.TextColumn("Employee ID"),
                "job_no":      st.column_config.TextColumn("Job #"),
                "machine_id":  st.column_config.TextColumn("Machine ID"),
                "op_code":     st.column_config.TextColumn("Op Code"),
                "op_desc":     st.column_config.TextColumn("Op Description"),
                "time_in":     st.column_config.DatetimeColumn("Time In"),
                "time_out":    st.column_config.DatetimeColumn("Time Out"),
                "setup_hours": st.column_config.NumberColumn("Setup Hrs", format="%.2f"),
                "run_hours":   st.column_config.NumberColumn("Run Hrs",   format="%.2f"),
                "qty_good":    st.column_config.NumberColumn("Qty Good",  step=1),
                "qty_scrap":   st.column_config.NumberColumn("Qty Scrap", step=1),
            }
        )


# -----------------------------------------------------------------------------
# MAIN APP ROUTER
# -----------------------------------------------------------------------------
page = st.session_state.page

if page == "Home":
    render_home_page()
elif page == "Add Asset":
    render_add_asset_page()
elif page == "View Assets":
    render_view_assets_page()
elif page == "Service Reports":
    render_service_page()
elif page == "ERP Dashboard":
    render_erp_dashboard_page()
elif page == "ETL Practice":
    render_etl_practice_page()
elif page == "Edit Asset":
    render_edit_asset_page()
elif page == "Records Manager":
    render_records_manager_page()
